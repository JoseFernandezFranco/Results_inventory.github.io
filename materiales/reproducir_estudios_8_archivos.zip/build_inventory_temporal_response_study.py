from __future__ import annotations

import argparse
import html
import json
import math
import sys
import urllib.request
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats


PROJECT_ROOT = Path(__file__).resolve().parent
PIPELINE_ROOT = PROJECT_ROOT / ".runtime" / "Definitivo_Limpio"
if str(PIPELINE_ROOT) not in sys.path:
    sys.path.insert(0, str(PIPELINE_ROOT))

from pipeline import render_layer


STUDY_ROOT = PROJECT_ROOT
DEFAULT_SENSOR_CSV = STUDY_ROOT / "combined_flags.csv"
DEFAULT_INVENTORY_CSV = STUDY_ROOT / "inventario_cartagena_maestro.csv"
DEFAULT_OUTPUT_DIR = STUDY_ROOT / "results" / "estudio_temporal_inventario_contaminacion_cartagena"
REFERENCE_CATALOG = [
    {
        "key": "carbon_monitor_2020",
        "authors": "Liu, Z. et al.",
        "year": 2020,
        "title": "Carbon Monitor: a near-real-time daily dataset of global CO2 emission from fossil fuel and cement production",
        "journal": "Scientific Data / arXiv preprint",
        "url": "https://arxiv.org/abs/2006.07690",
        "pdf_url": "https://arxiv.org/pdf/2006.07690.pdf",
        "local_filename": "01_carbon_monitor_2020.pdf",
        "role": "Justifica trabajar con emisiones diarias y leer el inventario como una señal temporal de actividad emisora.",
        "bibtex": (
            "@article{Liu2020CarbonMonitor,\n"
            "  title={Carbon Monitor: a near-real-time daily dataset of global CO2 emission from fossil fuel and cement production},\n"
            "  author={Liu, Zhu and others},\n"
            "  journal={arXiv preprint arXiv:2006.07690},\n"
            "  year={2020}\n"
            "}"
        ),
    },
    {
        "key": "near_real_time_cities_2022",
        "authors": "Gurney, K.R. et al.",
        "year": 2022,
        "title": "Near-real-time estimates of daily CO2 emissions from 1500 cities worldwide",
        "journal": "arXiv preprint",
        "url": "https://arxiv.org/abs/2204.07836",
        "pdf_url": "https://arxiv.org/pdf/2204.07836.pdf",
        "local_filename": "02_daily_city_co2_2022.pdf",
        "role": "Refuerza la relevancia de una lectura diaria de emisiones urbanas y su uso para seguimiento casi en tiempo real.",
        "bibtex": (
            "@article{Gurney2022Cities,\n"
            "  title={Near-real-time estimates of daily CO2 emissions from 1500 cities worldwide},\n"
            "  author={Gurney, Kevin R. and others},\n"
            "  journal={arXiv preprint arXiv:2204.07836},\n"
            "  year={2022}\n"
            "}"
        ),
    },
    {
        "key": "seoul_2018",
        "authors": "Kim, H.-C.; Kim, E.; Bae, C.; Cho, J.; Kim, B.-U.; Kim, S.",
        "year": 2018,
        "title": "Effects of meteorology and emissions on urban air quality: a quantitative statistical approach to long-term records (1999–2016) in Seoul, South Korea",
        "journal": "Atmospheric Chemistry and Physics, 18, 16121-16137",
        "url": "https://acp.copernicus.org/articles/18/16121/2018/",
        "pdf_url": "https://acp.copernicus.org/articles/18/16121/2018/acp-18-16121-2018.pdf",
        "local_filename": "03_seoul_2018_meteorology_emissions.pdf",
        "role": "Sustenta que en estudios temporales urbanos hay que interpretar contaminacion y emisiones junto a la meteorologia.",
        "bibtex": (
            "@article{Kim2018Seoul,\n"
            "  title={Effects of meteorology and emissions on urban air quality: a quantitative statistical approach to long-term records (1999--2016) in Seoul, South Korea},\n"
            "  author={Kim, H.-C. and Kim, E. and Bae, C. and Cho, J. and Kim, B.-U. and Kim, S.},\n"
            "  journal={Atmospheric Chemistry and Physics},\n"
            "  volume={18},\n"
            "  pages={16121--16137},\n"
            "  year={2018},\n"
            "  doi={10.5194/acp-18-16121-2018}\n"
            "}"
        ),
    },
    {
        "key": "viard_fu_2015",
        "authors": "Viard, B.; Fu, S.",
        "year": 2015,
        "title": "The effect of Beijing's driving restrictions on pollution and economic activity",
        "journal": "Journal of Public Economics, 125, 98-115",
        "url": "https://mpra.ub.uni-muenchen.de/33009/",
        "pdf_url": "https://mpra.ub.uni-muenchen.de/33009/1/MPRA_paper_33009.pdf",
        "local_filename": "04_viard_fu_2015_driving_restrictions.pdf",
        "role": "Aporta una referencia clasica para leer cambios temporales de contaminacion asociados a variaciones del trafico y la actividad.",
        "bibtex": (
            "@article{ViardFu2015,\n"
            "  title={The effect of Beijing's driving restrictions on pollution and economic activity},\n"
            "  author={Viard, Brian and Fu, Shihe},\n"
            "  journal={Journal of Public Economics},\n"
            "  volume={125},\n"
            "  pages={98--115},\n"
            "  year={2015}\n"
            "}"
        ),
    },
    {
        "key": "seville_2025",
        "authors": "Gonzalez-Garcia, M. et al.",
        "year": 2025,
        "title": "Air Quality Assessment During the Initial Implementation Phase of a Traffic-Restricted Zone in an Urban Area: A Case Study Based on NO2 Levels in Seville, Spain",
        "journal": "Processes, 13(3), 645",
        "url": "https://www.mdpi.com/2227-9717/13/3/645",
        "pdf_url": "https://idus.us.es/bitstreams/08e204fc-eeb4-433c-a515-08dd5e18a294/download",
        "local_filename": "05_seville_2025_lez_no2.pdf",
        "role": "Contexto espanol reciente para interpretar patrones temporales de NO2 bajo cambios de movilidad y condiciones meteorologicas.",
        "bibtex": (
            "@article{Seville2025LEZNO2,\n"
            "  title={Air Quality Assessment During the Initial Implementation Phase of a Traffic-Restricted Zone in an Urban Area: A Case Study Based on NO2 Levels in Seville, Spain},\n"
            "  author={Gonzalez-Garcia, M. and others},\n"
            "  journal={Processes},\n"
            "  volume={13},\n"
            "  number={3},\n"
            "  pages={645},\n"
            "  year={2025}\n"
            "}"
        ),
    },
]
PRIMARY_RELATIONSHIPS = [
    {
        "relation_id": "co2_direct",
        "label": "CO2 inventario -> CO2 sensores",
        "exposure": "emisiones_totales_co2_g",
        "exposure_label": "Emisiones CO2 inventario",
        "target": "CO2",
        "target_label": "CO2 observado",
        "raw_model_id": "co2_direct_raw",
        "adjusted_model_id": "co2_direct_meteo",
        "kind": "principal",
    },
    {
        "relation_id": "no2_direct",
        "label": "NOx inventario -> NO2 sensores",
        "exposure": "emisiones_totales_nox_g",
        "exposure_label": "Emisiones NOx inventario",
        "target": "NO2",
        "target_label": "NO2 observado",
        "raw_model_id": "no2_direct_raw",
        "adjusted_model_id": "no2_direct_meteo",
        "kind": "principal",
    },
    {
        "relation_id": "no2_activity",
        "label": "Actividad del inventario -> NO2 sensores",
        "exposure": "trips_total",
        "exposure_label": "Trayectos totales",
        "target": "NO2",
        "target_label": "NO2 observado",
        "raw_model_id": "no2_activity_raw",
        "adjusted_model_id": "no2_activity_meteo",
        "kind": "apoyo",
    },
]

MODEL_SPECS = [
    {
        "model_id": "co2_direct_raw",
        "title": "CO2 ~ emisiones_totales_co2_g",
        "outcome": "CO2",
        "outcome_label": "CO2 observado",
        "regressors": ["emisiones_totales_co2_g"],
        "regressor_labels": ["Emisiones CO2 inventario"],
        "story": "Relacion directa del mismo dia entre la masa diaria de CO2 del inventario y el CO2 medio observado por sensores.",
    },
    {
        "model_id": "co2_direct_meteo",
        "title": "CO2 ~ emisiones_totales_co2_g + meteo",
        "outcome": "CO2",
        "outcome_label": "CO2 observado",
        "regressors": ["emisiones_totales_co2_g", "temperature", "relativehumidity", "atmosphericpressure"],
        "regressor_labels": ["Emisiones CO2 inventario", "Temperatura", "Humedad relativa", "Presion atmosferica"],
        "story": "Misma relacion directa, pero ajustando por meteorologia diaria.",
    },
    {
        "model_id": "no2_direct_raw",
        "title": "NO2 ~ emisiones_totales_nox_g",
        "outcome": "NO2",
        "outcome_label": "NO2 observado",
        "regressors": ["emisiones_totales_nox_g"],
        "regressor_labels": ["Emisiones NOx inventario"],
        "story": "Relacion directa del mismo dia entre la masa diaria de NOx del inventario y el NO2 medio observado.",
    },
    {
        "model_id": "no2_direct_meteo",
        "title": "NO2 ~ emisiones_totales_nox_g + meteo",
        "outcome": "NO2",
        "outcome_label": "NO2 observado",
        "regressors": ["emisiones_totales_nox_g", "temperature", "relativehumidity", "atmosphericpressure"],
        "regressor_labels": ["Emisiones NOx inventario", "Temperatura", "Humedad relativa", "Presion atmosferica"],
        "story": "Relacion directa NOx-NO2 del mismo dia ajustada por meteorologia.",
    },
    {
        "model_id": "no2_activity_raw",
        "title": "NO2 ~ trips_total",
        "outcome": "NO2",
        "outcome_label": "NO2 observado",
        "regressors": ["trips_total"],
        "regressor_labels": ["Trayectos totales"],
        "story": "Lectura auxiliar para comprobar si NO2 sigue mejor la actividad diaria que la masa total de NOx.",
    },
    {
        "model_id": "no2_activity_meteo",
        "title": "NO2 ~ trips_total + meteo",
        "outcome": "NO2",
        "outcome_label": "NO2 observado",
        "regressors": ["trips_total", "temperature", "relativehumidity", "atmosphericpressure"],
        "regressor_labels": ["Trayectos totales", "Temperatura", "Humedad relativa", "Presion atmosferica"],
        "story": "Lectura auxiliar NO2-actividad ajustada por meteorologia diaria.",
    },
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Construye un estudio temporal no espacial entre el inventario diario de "
            "vehiculos conectados y CO2/NO2 observados por sensores."
        )
    )
    parser.add_argument("--sensor-csv", type=Path, default=DEFAULT_SENSOR_CSV)
    parser.add_argument("--inventory-csv", type=Path, default=DEFAULT_INVENTORY_CSV)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    parser.add_argument("--timezone", default="Europe/Madrid")
    return parser.parse_args()


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def format_short(value: object) -> str:
    return render_layer.format_number(value)


def reference_citation(ref: dict[str, object]) -> str:
    return f"{ref['authors']} ({ref['year']}). {ref['title']}. {ref['journal']}."


def load_inventory_daily(path: Path) -> pd.DataFrame:
    frame = pd.read_csv(path)
    frame["fecha"] = pd.to_datetime(frame["fecha"], errors="coerce")
    numeric_cols = [
        "emisiones_totales_nox_g",
        "emisiones_totales_co2_g",
        "trayectos_inician_y_finalizan",
        "trayectos_inician",
        "trayectos_finalizan",
        "trayectos_cruzan",
        "kms",
    ]
    for column in numeric_cols:
        frame[column] = pd.to_numeric(frame[column], errors="coerce").fillna(0.0)

    frame["trips_counted"] = frame["trayectos_finalizan"] + frame["trayectos_cruzan"]
    frame["trips_interior"] = frame["trayectos_inician_y_finalizan"]
    frame["trips_salidas"] = frame["trayectos_inician"]
    frame["trips_total"] = frame["trips_counted"] + frame["trips_interior"] + frame["trips_salidas"]

    daily = (
        frame.groupby("fecha", as_index=False)
        .agg(
            emisiones_totales_nox_g=("emisiones_totales_nox_g", "sum"),
            emisiones_totales_co2_g=("emisiones_totales_co2_g", "sum"),
            trips_total=("trips_total", "sum"),
            trips_counted=("trips_counted", "sum"),
            trips_interior=("trips_interior", "sum"),
            trips_salidas=("trips_salidas", "sum"),
            kms=("kms", "sum"),
            vehiculos=("matricula", "nunique"),
        )
        .sort_values("fecha")
        .reset_index(drop=True)
    )
    daily["share_counted"] = daily["trips_counted"] / daily["trips_total"]
    daily["share_interior"] = daily["trips_interior"] / daily["trips_total"]
    daily["share_salidas"] = daily["trips_salidas"] / daily["trips_total"]
    daily["nox_g_trip"] = daily["emisiones_totales_nox_g"] / daily["trips_total"]
    daily["co2_g_trip"] = daily["emisiones_totales_co2_g"] / daily["trips_total"]
    return daily


def load_city_daily(path: Path, timezone: str) -> tuple[pd.DataFrame, pd.DataFrame]:
    usecols = ["time", "dataset", "param", "analysis_value_default", "entity_id"]
    frame = pd.read_csv(path, usecols=usecols)
    frame["time"] = pd.to_datetime(frame["time"], utc=True)
    frame["local_day"] = frame["time"].dt.tz_convert(timezone).dt.tz_localize(None).dt.normalize()
    frame["analysis_value_default"] = pd.to_numeric(frame["analysis_value_default"], errors="coerce")
    frame = frame.dropna(subset=["analysis_value_default"]).copy()

    params = ["CO2", "NO2", "temperature", "relativehumidity", "atmosphericpressure", "precipitation", "coches_total"]
    frame = frame.loc[frame["param"].isin(params)].copy()

    pollutant_frame = frame.loc[frame["dataset"].astype(str).isin(["air_quality", "weather", "traffic"])].copy()
    daily_mean = (
        pollutant_frame.groupby(["local_day", "param"], as_index=False)["analysis_value_default"]
        .mean()
        .pivot(index="local_day", columns="param", values="analysis_value_default")
        .reset_index()
    )
    daily_meta = (
        pollutant_frame.groupby(["local_day", "param"], as_index=False)
        .agg(
            rows=("analysis_value_default", "size"),
            entities=("entity_id", "nunique"),
        )
        .pivot(index="local_day", columns="param")
    )
    daily_meta.columns = [f"{name}_{param}" for name, param in daily_meta.columns]
    daily_meta = daily_meta.reset_index()
    return daily_mean, daily_meta


def merge_daily(inventory_daily: pd.DataFrame, city_daily: pd.DataFrame, city_meta: pd.DataFrame) -> pd.DataFrame:
    merged = inventory_daily.merge(city_daily, left_on="fecha", right_on="local_day", how="inner")
    merged = merged.merge(city_meta, on="local_day", how="left")
    merged = merged.sort_values("fecha").reset_index(drop=True)
    merged["day_label"] = merged["fecha"].dt.strftime("%Y-%m-%d")
    for column in [
        "emisiones_totales_co2_g",
        "emisiones_totales_nox_g",
        "trips_total",
        "kms",
        "co2_g_trip",
        "nox_g_trip",
        "CO2",
        "NO2",
        "temperature",
        "relativehumidity",
        "atmosphericpressure",
        "precipitation",
        "coches_total",
    ]:
        values = pd.to_numeric(merged[column], errors="coerce")
        std = float(values.std(ddof=0))
        merged[f"{column}_z"] = (values - float(values.mean())) / std if std > 0 else 0.0
    return merged


def lag_correlations(frame: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, object]] = []
    for metric, metric_label in LAG_METRICS:
        for target, target_label in [("CO2", "CO2"), ("NO2", "NO2")]:
            for lag in [-2, -1, 0, 1, 2]:
                temp = frame[[metric, target]].copy()
                temp["x_lag"] = temp[metric].shift(lag)
                subset = temp[["x_lag", target]].dropna()
                if len(subset) < 5:
                    continue
                rows.append(
                    {
                        "metric": metric,
                        "metric_label": metric_label,
                        "target": target,
                        "target_label": target_label,
                        "lag_days": lag,
                        "n_obs": int(len(subset)),
                        "pearson": float(subset["x_lag"].corr(subset[target])),
                        "spearman": float(subset["x_lag"].corr(subset[target], method="spearman")),
                    }
                )
    return pd.DataFrame(rows).sort_values(["target", "metric", "lag_days"]).reset_index(drop=True)


def ols_fit(X: np.ndarray, y: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    beta, _, _, _ = np.linalg.lstsq(X, y, rcond=None)
    fitted = X @ beta
    resid = y - fitted
    return beta, fitted, resid


def robust_hc1_cov(X: np.ndarray, resid: np.ndarray) -> np.ndarray:
    n_obs, n_params = X.shape
    xtx_inv = np.linalg.pinv(X.T @ X)
    meat = X.T @ ((resid[:, None] ** 2) * X)
    scale = n_obs / max(n_obs - n_params, 1)
    return xtx_inv @ meat @ xtx_inv * scale


def fit_model(frame: pd.DataFrame, spec: dict[str, object]) -> tuple[pd.DataFrame, dict[str, object]]:
    subset = frame[[spec["outcome"]] + list(spec["regressors"])].dropna().copy()
    y = pd.to_numeric(subset[spec["outcome"]], errors="coerce").to_numpy(dtype=float)
    X = np.column_stack(
        [np.ones(len(subset), dtype=float)]
        + [pd.to_numeric(subset[reg], errors="coerce").to_numpy(dtype=float) for reg in spec["regressors"]]
    )
    beta, fitted, resid = ols_fit(X, y)
    cov = robust_hc1_cov(X, resid)
    se = np.sqrt(np.clip(np.diag(cov), a_min=0.0, a_max=None))
    df_resid = max(len(subset) - X.shape[1], 1)
    r2 = 1.0 - float(np.sum(resid**2)) / float(np.sum((y - y.mean()) ** 2)) if len(subset) > 1 else float("nan")

    rows: list[dict[str, object]] = []
    for index, reg in enumerate(spec["regressors"], start=1):
        coef = float(beta[index])
        stderr = float(se[index])
        t_value = coef / stderr if stderr > 0 else float("nan")
        p_value = float(2 * stats.t.sf(abs(t_value), df=df_resid)) if stderr > 0 else float("nan")
        ci_low = coef - 1.96 * stderr if stderr > 0 else float("nan")
        ci_high = coef + 1.96 * stderr if stderr > 0 else float("nan")
        raw_x = pd.to_numeric(subset[reg], errors="coerce")
        iqr = float(raw_x.quantile(0.75) - raw_x.quantile(0.25))
        rows.append(
            {
                "model_id": spec["model_id"],
                "model_title": spec["title"],
                "outcome": spec["outcome"],
                "outcome_label": spec["outcome_label"],
                "regressor": reg,
                "regressor_label": spec["regressor_labels"][index - 1],
                "coefficient": coef,
                "std_error": stderr,
                "t_value": t_value,
                "p_value": p_value,
                "ci_low": ci_low,
                "ci_high": ci_high,
                "r2": r2,
                "n_obs": int(len(subset)),
                "iqr_x": iqr,
                "iqr_effect": coef * iqr,
                "story": spec["story"],
            }
        )

    summary = {
        "model_id": spec["model_id"],
        "title": spec["title"],
        "outcome": spec["outcome"],
        "n_obs": int(len(subset)),
        "r2": r2,
        "intercept": float(beta[0]),
    }
    return pd.DataFrame(rows), summary


def regression_line(points: list[dict[str, float]]) -> list[dict[str, float]]:
    if len(points) < 2:
        return points
    x = np.array([row["x"] for row in points], dtype=float)
    y = np.array([row["y"] for row in points], dtype=float)
    slope, intercept = np.polyfit(x, y, 1)
    xs = np.linspace(float(x.min()), float(x.max()), 40)
    return [{"x": float(value), "y": float(intercept + slope * value)} for value in xs]


def scatter_points(frame: pd.DataFrame, x: str, y: str) -> list[dict[str, object]]:
    subset = frame[[x, y, "day_label"]].dropna().copy()
    return [
        {"x": float(row[x]), "y": float(row[y]), "label": str(row["day_label"])}
        for _, row in subset.iterrows()
    ]


def chart_series(frame: pd.DataFrame, columns: list[str], labels: list[str] | None = None) -> list[dict[str, object]]:
    series: list[dict[str, object]] = []
    for index, column in enumerate(columns):
        label = labels[index] if labels else column
        series.append(
            {
                "label": label,
                "data": [float(value) if pd.notna(value) else None for value in frame[column]],
            }
        )
    return series


def exposure_profiles(frame: pd.DataFrame) -> pd.DataFrame:
    result_rows: list[dict[str, object]] = []
    for relation in PRIMARY_RELATIONSHIPS:
        metric = str(relation["exposure"])
        target = str(relation["target"])
        ranked = frame[[metric, target]].copy()
        ranked["group"] = pd.qcut(ranked[metric], q=3, labels=["bajo", "medio", "alto"], duplicates="drop")
        profile = ranked.groupby("group", observed=False, as_index=False)[target].mean()
        for _, row in profile.iterrows():
            result_rows.append(
                {
                    "relation_id": relation["relation_id"],
                    "relation_label": relation["label"],
                    "metric": metric,
                    "metric_label": relation["exposure_label"],
                    "target": target,
                    "target_label": relation["target_label"],
                    "group": row["group"],
                    "target_mean": float(row[target]),
                }
            )
    return pd.DataFrame(result_rows)


def same_day_relationships(frame: pd.DataFrame, model_results: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, object]] = []
    for relation in PRIMARY_RELATIONSHIPS:
        exposure = str(relation["exposure"])
        target = str(relation["target"])
        pair = frame[[exposure, target]].dropna().copy()
        raw_row = model_results.loc[
            (model_results["model_id"] == relation["raw_model_id"]) & (model_results["regressor"] == exposure)
        ].iloc[0]
        adjusted_row = model_results.loc[
            (model_results["model_id"] == relation["adjusted_model_id"]) & (model_results["regressor"] == exposure)
        ].iloc[0]
        pearson = float(pair[exposure].corr(pair[target]))
        spearman = float(pair[exposure].corr(pair[target], method="spearman"))
        abs_pearson = abs(pearson)
        if abs_pearson >= 0.5:
            reading = "senal visible"
        elif abs_pearson >= 0.25:
            reading = "senal debil o moderada"
        else:
            reading = "sin senal clara"
        rows.append(
            {
                "relation_id": relation["relation_id"],
                "relation_label": relation["label"],
                "kind": relation["kind"],
                "exposure": exposure,
                "exposure_label": relation["exposure_label"],
                "target": target,
                "target_label": relation["target_label"],
                "pearson_same_day": pearson,
                "spearman_same_day": spearman,
                "raw_coef": float(raw_row["coefficient"]),
                "raw_p_value": float(raw_row["p_value"]),
                "raw_r2": float(raw_row["r2"]),
                "adjusted_coef": float(adjusted_row["coefficient"]),
                "adjusted_p_value": float(adjusted_row["p_value"]),
                "adjusted_r2": float(adjusted_row["r2"]),
                "reading": reading,
            }
        )
    return pd.DataFrame(rows)


def download_reference_pdfs(references_dir: Path) -> list[dict[str, object]]:
    manifest: list[dict[str, object]] = []
    for ref in REFERENCE_CATALOG:
        entry = {
            "key": ref["key"],
            "citation": reference_citation(ref),
            "url": ref["url"],
            "role": ref["role"],
            "local_file": None,
            "download_status": "not_attempted",
        }
        if ref.get("pdf_url") and ref.get("local_filename"):
            destination = references_dir / str(ref["local_filename"])
            try:
                request = urllib.request.Request(str(ref["pdf_url"]), headers={"User-Agent": "Mozilla/5.0"})
                with urllib.request.urlopen(request, timeout=30) as response:
                    payload = response.read()
                if not payload.startswith(b"%PDF"):
                    raise ValueError("The downloaded payload is not a PDF.")
                destination.write_bytes(payload)
                entry["local_file"] = str(destination)
                entry["download_status"] = "downloaded"
            except Exception as exc:  # pragma: no cover
                entry["download_status"] = f"failed: {exc}"
        manifest.append(entry)
    return manifest


def write_reference_materials(references_dir: Path, reference_manifest: list[dict[str, object]]) -> None:
    lines = [
        "# Referencias del estudio temporal",
        "",
        "Esta carpeta documenta por que este estudio trabaja con agregacion diaria, comparaciones directas del mismo dia y modelos simples ajustados por meteorologia.",
        "",
    ]
    procedure_lines = [
        "# Procedimiento basado en papers",
        "",
        "## 1. Agregacion diaria",
        "- El inventario se resume por dia porque esa es su resolucion natural.",
        "- Los sensores se agregan a medias diarias ciudadanas por parametro.",
        "",
        "## 2. Variables principales",
        "- `CO2` y `NO2` son los contaminantes objetivo.",
        "- Se trabaja con masa diaria total y actividad total del mismo dia.",
        "",
        "## 3. Relacion inventario-sensor",
        "- Se comparan pares directos del mismo dia: CO2 inventario vs CO2 sensores y NOx inventario vs NO2 sensores.",
        "- Se aade una lectura auxiliar de actividad: trayectos totales vs NO2.",
        "- Se ajustan modelos OLS simples y modelos OLS con meteorologia.",
        "",
        "## 4. Lectura del estudio",
        "- Este run estima asociacion temporal diaria, no causalidad dura.",
        "",
        "## Papers usados",
    ]
    bibtex_entries: list[str] = []

    for ref, manifest in zip(REFERENCE_CATALOG, reference_manifest):
        local_line = "PDF local no disponible."
        if manifest.get("local_file"):
            local_line = f"PDF local: {Path(manifest['local_file']).name}"
        lines.extend(
            [
                f"## {ref['title']}",
                "",
                f"- Cita: {reference_citation(ref)}",
                f"- Uso en el estudio: {ref['role']}",
                f"- URL: {ref['url']}",
                f"- Estado de descarga: {manifest['download_status']}",
                f"- {local_line}",
                "",
            ]
        )
        procedure_lines.extend(
            [
                f"### {ref['year']} - {ref['title']}",
                f"- Uso en este estudio: {ref['role']}",
                f"- URL: {ref['url']}",
                "",
            ]
        )
        bibtex_entries.append(ref["bibtex"])

    (references_dir / "referencias_y_metodo.md").write_text("\n".join(lines), encoding="utf-8")
    (references_dir / "procedimiento_basado_en_papers.md").write_text("\n".join(procedure_lines), encoding="utf-8")
    (references_dir / "references.bib").write_text("\n\n".join(bibtex_entries) + "\n", encoding="utf-8")
    (references_dir / "download_manifest.json").write_text(
        json.dumps(reference_manifest, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    references_html = """<!doctype html>
<html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Referencias del estudio temporal</title>
<style>
body{margin:0;font-family:"Aptos","Segoe UI",sans-serif;background:#f4f7fa;color:#24303a}
main{max-width:980px;margin:0 auto;padding:24px 18px 32px}
.panel{background:#fff;border:1px solid #dde6ed;border-radius:20px;padding:22px;margin-bottom:18px;box-shadow:0 14px 30px rgba(15,38,56,.08)}
h1,h2{margin-top:0} p,li{line-height:1.65;color:#5d6b77} a{color:#0c5f7b;text-decoration:none} a:hover{text-decoration:underline}
</style></head><body><main>
<section class="panel"><h1>Referencias del estudio temporal</h1><p>Relación de papers usados para apoyar la lectura diaria de emisiones urbanas, meteorología y contaminación.</p></section>
""" + "".join(
        (
            "<section class=\"panel\">"
            f"<h2>{html.escape(ref['title'])}</h2>"
            f"<p><strong>Cita:</strong> {html.escape(reference_citation(ref))}</p>"
            f"<p><strong>Uso en el estudio:</strong> {html.escape(ref['role'])}</p>"
            f"<p><a href=\"{html.escape(ref['url'])}\">Fuente web</a>"
            + (
                f" | <a href=\"{Path(manifest['local_file']).name}\">PDF local</a>"
                if manifest.get("local_file")
                else ""
            )
            + "</p></section>"
        )
        for ref, manifest in zip(REFERENCE_CATALOG, reference_manifest)
    ) + "</main></body></html>"
    (references_dir / "index.html").write_text(references_html, encoding="utf-8")

    procedure_html = """<!doctype html>
<html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Procedimiento del estudio temporal</title>
<style>
body{margin:0;font-family:"Aptos","Segoe UI",sans-serif;background:#f4f7fa;color:#24303a}
main{max-width:980px;margin:0 auto;padding:24px 18px 32px}
.panel{background:#fff;border:1px solid #dde6ed;border-radius:20px;padding:22px;margin-bottom:18px;box-shadow:0 14px 30px rgba(15,38,56,.08)}
h1,h2{margin-top:0} p,li{line-height:1.65;color:#5d6b77} a{color:#0c5f7b;text-decoration:none} a:hover{text-decoration:underline}
</style></head><body><main>
<section class="panel"><h1>Procedimiento del estudio temporal</h1><p>Resumen corto del diseño no espacial usado en este run.</p></section>
<section class="panel"><h2>1. Agregación</h2><p>Inventario diario y medias diarias de sensores a escala ciudad, sin interpolación espacial.</p></section>
<section class="panel"><h2>2. Variables</h2><p>El foco se limita a <strong>CO2</strong> y <strong>NO2</strong>. No se usa O3 en esta fase.</p></section>
<section class="panel"><h2>3. Relación</h2><p>Se calculan series temporales normalizadas, correlaciones con retardos y modelos diarios simples con y sin meteorología.</p></section>
<section class="panel"><h2>4. Lectura</h2><p>Este estudio estima asociación temporal y sensibilidad diaria, no causalidad fuerte.</p></section>
<section class="panel"><h2>5. Referencias</h2><p>Consulta también <a href="index.html">la página de referencias</a> y los archivos <code>references.bib</code>, <code>referencias_y_metodo.md</code> y <code>procedimiento_basado_en_papers.md</code>.</p></section>
</main></body></html>"""
    (references_dir / "procedure.html").write_text(procedure_html, encoding="utf-8")


def build_chart_payload(
    daily: pd.DataFrame,
    profiles: pd.DataFrame,
) -> dict[str, object]:
    co2_scatter = scatter_points(daily, "emisiones_totales_co2_g", "CO2")
    no2_direct_scatter = scatter_points(daily, "emisiones_totales_nox_g", "NO2")
    no2_activity_scatter = scatter_points(daily, "trips_total", "NO2")
    payload = {
        "labels": daily["day_label"].tolist(),
        "co2DirectLine": chart_series(
            daily,
            ["emisiones_totales_co2_g_z", "CO2_z"],
            ["CO2 inventario", "CO2 sensores"],
        ),
        "no2DirectLine": chart_series(
            daily,
            ["emisiones_totales_nox_g_z", "NO2_z"],
            ["NOx inventario", "NO2 sensores"],
        ),
        "no2ActivityLine": chart_series(daily, ["trips_total_z", "NO2_z"], ["Trayectos", "NO2 sensores"]),
        "tripMix": {
            "labels": daily["day_label"].tolist(),
            "datasets": [
                {"label": "Counted", "data": [float(value) for value in daily["trips_counted"]]},
                {"label": "Interior", "data": [float(value) for value in daily["trips_interior"]]},
                {"label": "Salidas", "data": [float(value) for value in daily["trips_salidas"]]},
            ],
        },
        "co2DirectScatter": co2_scatter,
        "co2DirectTrend": regression_line(co2_scatter),
        "no2DirectScatter": no2_direct_scatter,
        "no2DirectTrend": regression_line(no2_direct_scatter),
        "no2ActivityScatter": no2_activity_scatter,
        "no2ActivityTrend": regression_line(no2_activity_scatter),
        "profiles": profiles.to_dict(orient="records"),
    }
    return payload


def dataframe_html(frame: pd.DataFrame, columns: list[str]) -> str:
    if frame.empty:
        return "<p>Sin resultados.</p>"
    view = frame[columns].copy()
    for column in view.columns:
        if pd.api.types.is_datetime64_any_dtype(view[column]):
            view[column] = pd.to_datetime(view[column]).dt.strftime("%Y-%m-%d")
        elif pd.api.types.is_numeric_dtype(view[column]):
            view[column] = view[column].map(render_layer.format_number)
    return view.to_html(index=False, border=0, classes="stats-table")


def build_summary_html(
    output_dir: Path,
    daily: pd.DataFrame,
    lag_frame: pd.DataFrame,
    model_results: pd.DataFrame,
    model_meta: pd.DataFrame,
    profiles: pd.DataFrame,
    charts: dict[str, object],
    reference_manifest: list[dict[str, object]],
) -> str:
    references_link = render_layer.relative_link(output_dir, output_dir / "references" / "index.html")
    procedure_link = render_layer.relative_link(output_dir, output_dir / "references" / "procedure.html")
    best_no2_same_day = lag_frame.loc[(lag_frame["metric"] == "trips_total") & (lag_frame["target"] == "NO2") & (lag_frame["lag_days"] == 0)].iloc[0]
    best_co2_same_day = lag_frame.loc[(lag_frame["metric"] == "emisiones_totales_co2_g") & (lag_frame["target"] == "CO2") & (lag_frame["lag_days"] == 0)].iloc[0]
    best_co2_lag = best_lag_row(lag_frame, "co2_g_trip", "CO2")
    best_no2_lag = best_lag_row(lag_frame, "trips_total", "NO2")
    model_lookup = {row["model_id"]: row for _, row in model_results.loc[model_results["regressor"] == model_results["regressor"]].iterrows()}
    profiles_view = profiles.rename(
        columns={
            "metric_label": "Metrica",
            "group": "Grupo",
            "CO2_mean": "CO2 medio",
            "NO2_mean": "NO2 medio",
        }
    )
    model_view = model_results.rename(
        columns={
            "model_title": "Modelo",
            "regressor_label": "Variable",
            "coefficient": "Coeficiente",
            "std_error": "SE robusta",
            "p_value": "p-value",
            "ci_low": "CI 95% inf",
            "ci_high": "CI 95% sup",
            "r2": "R2",
            "n_obs": "Observaciones",
            "iqr_effect": "Efecto IQR",
        }
    )
    meta_view = model_meta.rename(
        columns={
            "model_id": "model_id",
            "title": "Modelo",
            "outcome": "Outcome",
            "n_obs": "Observaciones",
            "r2": "R2",
        }
    )
    daily_table = daily.rename(
        columns={
            "day_label": "Dia",
            "emisiones_totales_co2_g": "CO2 inventario",
            "emisiones_totales_nox_g": "NOx inventario",
            "trips_total": "Trayectos",
            "co2_g_trip": "CO2 g/viaje",
            "nox_g_trip": "NOx g/viaje",
            "CO2": "CO2 observado",
            "NO2": "NO2 observado",
            "temperature": "Temperatura",
            "relativehumidity": "Humedad",
            "atmosphericpressure": "Presion",
        }
    )
    reference_items = []
    for manifest in reference_manifest:
        local_html = ""
        if manifest.get("local_file"):
            local_html = f" | <a href=\"{render_layer.relative_link(output_dir, Path(manifest['local_file']))}\">PDF local</a>"
        reference_items.append(
            "<li>"
            f"<strong>{html.escape(manifest['citation'])}</strong><br>"
            f"{html.escape(manifest['role'])}<br>"
            f"<a href=\"{html.escape(manifest['url'])}\">Fuente web</a>{local_html}"
            "</li>"
        )

    charts_json = json.dumps(charts, ensure_ascii=False)
    return f"""<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Estudio temporal inventario-contaminación</title>
  <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.2"></script>
  <style>
    :root {{
      --bg: #eef3f6;
      --panel: rgba(255,255,255,0.95);
      --ink: #22303b;
      --muted: #5d6b77;
      --line: #d7e1e8;
      --blue: #0b6c88;
      --green: #17795b;
      --orange: #c56024;
      --pink: #b14678;
      --shadow: 0 20px 44px rgba(15, 38, 56, 0.10);
    }}
    body {{
      margin: 0;
      color: var(--ink);
      font-family: "Aptos", "Segoe UI", "Helvetica Neue", sans-serif;
      background:
        radial-gradient(circle at top left, rgba(11, 108, 136, 0.12), transparent 24%),
        radial-gradient(circle at 88% 10%, rgba(197, 96, 36, 0.10), transparent 22%),
        linear-gradient(180deg, #f7f9fb 0%, #eef3f6 100%);
    }}
    main {{ max-width: 1360px; margin: 0 auto; padding: 24px 18px 36px; }}
    .panel {{
      background: var(--panel);
      border: 1px solid rgba(20,53,74,.08);
      border-radius: 26px;
      padding: 24px;
      margin-bottom: 20px;
      box-shadow: var(--shadow);
    }}
    .eyebrow {{
      display:inline-flex; padding:8px 12px; border-radius:999px; background:rgba(11,108,136,.10);
      color:var(--blue); font-size:12px; font-weight:800; letter-spacing:.10em; text-transform:uppercase; margin-bottom:12px;
    }}
    h1,h2,h3{{margin-top:0}}
    h1{{font-size:42px; line-height:1.02; letter-spacing:-.04em; margin-bottom:10px; color:var(--blue)}}
    h2{{font-size:24px; letter-spacing:-.02em; margin-bottom:12px}}
    p, li{{color:var(--muted); line-height:1.65}}
    .hero-grid{{display:grid; grid-template-columns:minmax(0,1.45fr) minmax(340px,.95fr); gap:22px; align-items:start}}
    .kpi-grid{{display:grid; grid-template-columns:repeat(2,minmax(0,1fr)); gap:14px}}
    .kpi{{border:1px solid rgba(20,53,74,.08); border-radius:18px; padding:16px; background:rgba(255,255,255,.84)}}
    .kpi span{{display:block; font-size:11px; letter-spacing:.10em; text-transform:uppercase; color:var(--muted); font-weight:800; margin-bottom:10px}}
    .kpi strong{{display:block; font-size:32px; line-height:1; color:var(--blue); margin-bottom:8px}}
    .pill-row{{display:flex; gap:10px; flex-wrap:wrap; margin-top:14px}}
    .pill{{display:inline-flex; align-items:center; padding:9px 12px; border-radius:999px; border:1px solid var(--line); background:#fff; font-size:13px; color:var(--muted); font-weight:700}}
    .pill strong{{color:var(--ink); margin-left:6px}}
    .story-grid{{display:grid; grid-template-columns:repeat(2,minmax(0,1fr)); gap:16px}}
    .story{{border-radius:18px; padding:18px; border:1px solid rgba(20,53,74,.08); background:linear-gradient(180deg,#fff 0%, #f5f8fb 100%)}}
    .story.co2{{border-left:6px solid var(--green)}}
    .story.no2{{border-left:6px solid var(--orange)}}
    .tag{{font-size:11px; font-weight:800; letter-spacing:.12em; text-transform:uppercase; color:var(--muted); margin-bottom:10px}}
    .story strong{{display:block; font-size:24px; margin-bottom:8px}}
    .formula{{padding:16px; border-radius:16px; background:#f7fafc; border:1px solid var(--line); overflow-x:auto; font-family:"Cascadia Code","Consolas",monospace; font-size:13px; color:#33404a; line-height:1.6; white-space:pre-wrap}}
    .two-col{{display:grid; grid-template-columns:repeat(2,minmax(0,1fr)); gap:18px}}
    .chart-card{{border:1px solid rgba(20,53,74,.08); border-radius:18px; padding:16px; background:#fff}}
    .chart-shell{{position:relative; height:320px; min-height:320px}}
    .chart-shell.tall{{height:340px; min-height:340px}}
    .chart-shell canvas{{position:absolute; inset:0; width:100% !important; height:100% !important; display:block}}
    .heatmap{{display:grid; gap:8px}}
    .heatmap-row{{display:grid; grid-template-columns:190px repeat(5, minmax(0,1fr)); gap:8px; align-items:center}}
    .heatmap-label{{font-size:13px; font-weight:700; color:var(--ink)}}
    .heatmap-cell{{padding:10px 8px; border-radius:12px; text-align:center; font-size:13px; font-weight:700; color:#17212b}}
    .stats-table{{width:100%; border-collapse:collapse; font-size:14px}}
    .stats-table th,.stats-table td{{padding:10px 12px; border-bottom:1px solid var(--line); text-align:left; vertical-align:top}}
    .stats-table th{{font-size:11px; letter-spacing:.10em; text-transform:uppercase; color:var(--muted); background:rgba(247,250,252,.92)}}
    .callout{{padding:16px 18px; border-radius:16px; background:#fff; border:1px dashed rgba(11,108,136,.28); color:var(--muted)}}
    ul.refs{{margin:0; padding-left:20px}} ul.refs li{{margin-bottom:14px}}
    a{{color:var(--blue); text-decoration:none}} a:hover{{text-decoration:underline}}
    @media (max-width:1040px){{.hero-grid,.story-grid,.two-col{{grid-template-columns:1fr}} .heatmap-row{{grid-template-columns:1fr repeat(5,minmax(0,1fr));}}}}
    @media (max-width:720px){{main{{padding:14px 10px 28px}} .panel{{padding:18px; border-radius:18px}} h1{{font-size:32px}} .kpi-grid{{grid-template-columns:1fr}} }}
  </style>
</head>
<body>
  <main>
    <section class="panel">
      <span class="eyebrow">Estudio temporal diario sin componente espacial</span>
      <div class="hero-grid">
        <div>
          <h1>Inventario diario y respuesta temporal de CO2 y NO2</h1>
          <p>Este estudio trabaja a escala <strong>ciudad-día</strong>. El objetivo es ver si la presión emisora diaria del inventario se refleja en los contaminantes medios medidos por sensores, sin recurrir a interpolaciones espaciales. El resultado es más sobrio que un mapa, pero más directo respecto a la estructura real de tus datos.</p>
          <div class="pill-row">
            <div class="pill">Periodo<strong>{html.escape(daily['day_label'].iloc[0])} a {html.escape(daily['day_label'].iloc[-1])}</strong></div>
            <div class="pill">Dias solapados<strong>{format_short(len(daily))}</strong></div>
            <div class="pill">CO2 sensores/dia<strong>{format_short(daily['entities_CO2'].mean())}</strong></div>
            <div class="pill">NO2 sensores/dia<strong>{format_short(daily['entities_NO2'].mean())}</strong></div>
          </div>
        </div>
        <div class="kpi-grid">
          <div class="kpi">
            <span>NO2 mismo dia</span>
            <strong>{format_short(best_no2_same_day['pearson'])}</strong>
            <p>Correlacion de <code>trips_total</code> con NO2 el mismo dia.</p>
          </div>
          <div class="kpi">
            <span>CO2 mismo dia</span>
            <strong>{format_short(best_co2_same_day['pearson'])}</strong>
            <p>Correlacion de <code>emisiones_totales_co2_g</code> con CO2 el mismo dia.</p>
          </div>
          <div class="kpi">
            <span>Mejor lag CO2</span>
            <strong>{format_short(best_co2_lag['pearson'])}</strong>
            <p><code>{html.escape(best_co2_lag['metric'])}</code> con CO2, lag {format_short(best_co2_lag['lag_days'])} dias.</p>
          </div>
          <div class="kpi">
            <span>Mejor lag NO2</span>
            <strong>{format_short(best_no2_lag['pearson'])}</strong>
            <p><code>{html.escape(best_no2_lag['metric'])}</code> con NO2, lag {format_short(best_no2_lag['lag_days'])} dias.</p>
          </div>
        </div>
      </div>
    </section>

    <section class="panel">
      <h2>Lectura principal</h2>
      <div class="story-grid">
        <div class="story co2">
          <div class="tag">CO2</div>
          <strong>La masa diaria total del inventario no explica bien el CO2 medio del dia</strong>
          <p>En este corte tan corto, el CO2 ambiente no responde de forma limpia a la masa diaria total del inventario. La señal más parecida aparece en métricas de intensidad o con un pequeño desfase temporal, así que el estudio sirve más para diagnosticar límites del dato que para cerrar una relación causal.</p>
        </div>
        <div class="story no2">
          <div class="tag">NO2</div>
          <strong>NO2 se alinea mejor con actividad diaria que con masa NOx total</strong>
          <p>La actividad diaria del inventario, medida como <code>trips_total</code>, se mueve bastante mejor con NO2 que la masa diaria total de NOx. Eso sugiere que, con tu ventana temporal, el inventario aporta más como señal de movilidad que como estimador fino de masa emisora observada.</p>
        </div>
      </div>
    </section>

    <section class="panel">
      <h2>Formulacion</h2>
      <div class="formula">1. Inventario diario
I_d = sum(emisiones, viajes, kms, composicion)

2. Sensores diarios ciudad
C_d = mean_estaciones(contaminante_d)
M_d = mean_estaciones(meteorologia_d)

3. Relacion temporal
corr(I_d, C_d)
corr(I_(d-k), C_d), k in [-2, -1, 0, 1, 2]

4. Modelos ajustados
C_d = alpha + beta * I_d + gamma * M_d + error_d

El objetivo no es estimar causalidad dura, sino ver si el inventario diario contiene una señal temporal interpretable sobre CO2 y NO2 a escala ciudad.</div>
      <p class="callout">La metodología y las referencias están en <a href="{html.escape(procedure_link)}">procedure.html</a> y <a href="{html.escape(references_link)}">index.html</a>.</p>
    </section>

    <section class="panel">
      <h2>Series diarias normalizadas</h2>
      <div class="two-col">
        <div class="chart-card">
          <h3>CO2: inventario frente a ambiente</h3>
          <div class="chart-shell"><canvas id="co2LineChart"></canvas></div>
        </div>
        <div class="chart-card">
          <h3>NO2: actividad del inventario frente a ambiente</h3>
          <div class="chart-shell"><canvas id="no2LineChart"></canvas></div>
        </div>
      </div>
    </section>

    <section class="panel">
      <h2>Scatters diarios</h2>
      <div class="two-col">
        <div class="chart-card">
          <h3>CO2 observado vs CO2 inventario</h3>
          <div class="chart-shell"><canvas id="co2ScatterChart"></canvas></div>
        </div>
        <div class="chart-card">
          <h3>NO2 observado vs trayectos totales</h3>
          <div class="chart-shell"><canvas id="no2ScatterChart"></canvas></div>
        </div>
      </div>
    </section>

    <section class="panel">
      <h2>Composicion diaria del inventario</h2>
      <div class="chart-card">
        <h3>Trayectos counted, interior y salidas</h3>
        <div class="chart-shell tall"><canvas id="tripMixChart"></canvas></div>
      </div>
    </section>

    <section class="panel">
      <h2>Correlaciones con retardos</h2>
      <p>Retardo negativo significa que la métrica del inventario antecede al contaminante; positivo, que el contaminante antecede a la métrica. Con solo 10 días, esto es descriptivo y no causal.</p>
      <div class="two-col">
        <div>
          <h3>CO2</h3>
          <div id="co2Heatmap" class="heatmap"></div>
        </div>
        <div>
          <h3>NO2</h3>
          <div id="no2Heatmap" class="heatmap"></div>
        </div>
      </div>
    </section>

    <section class="panel">
      <h2>Modelos diarios</h2>
      {dataframe_html(model_view, ['Modelo', 'Variable', 'Coeficiente', 'SE robusta', 'p-value', 'CI 95% inf', 'CI 95% sup', 'R2', 'Observaciones', 'Efecto IQR'])}
    </section>

    <section class="panel">
      <h2>Promedios por tramos del inventario</h2>
      {dataframe_html(profiles_view, ['Metrica', 'Grupo', 'CO2 medio', 'NO2 medio'])}
    </section>

    <section class="panel">
      <h2>Metadatos de modelos</h2>
      {dataframe_html(meta_view, ['model_id', 'Modelo', 'Outcome', 'Observaciones', 'R2'])}
    </section>

    <section class="panel">
      <h2>Panel diario usado</h2>
      {dataframe_html(daily_table, ['Dia', 'CO2 inventario', 'NOx inventario', 'Trayectos', 'CO2 g/viaje', 'NOx g/viaje', 'CO2 observado', 'NO2 observado', 'Temperatura', 'Humedad', 'Presion'])}
    </section>

    <section class="panel">
      <h2>Referencias incluidas</h2>
      <ul class="refs">
        {''.join(reference_items)}
      </ul>
    </section>
  </main>

  <script>
    const charts = {charts_json};

    function lineDatasets(series, palette) {{
      return series.map((item, idx) => ({{
        label: item.label,
        data: item.data,
        borderColor: palette[idx % palette.length],
        backgroundColor: palette[idx % palette.length],
        pointRadius: 4,
        borderWidth: 2.5,
        tension: 0.25,
        fill: false
      }}));
    }}

    function buildLineChart(id, labels, series, palette) {{
      new Chart(document.getElementById(id), {{
        type: 'line',
        data: {{
          labels,
          datasets: lineDatasets(series, palette)
        }},
        options: {{
          responsive: true,
          maintainAspectRatio: false,
          plugins: {{
            legend: {{ position: 'bottom' }}
          }},
          scales: {{
            y: {{ title: {{ display: true, text: 'z-score diario' }} }}
          }}
        }}
      }});
    }}

    function buildScatterChart(id, points, trend, palette, xLabel, yLabel) {{
      new Chart(document.getElementById(id), {{
        type: 'scatter',
        data: {{
          datasets: [
            {{
              label: 'Dias',
              data: points,
              backgroundColor: palette[0],
              borderColor: palette[0],
              pointRadius: 5
            }},
            {{
              label: 'Ajuste lineal',
              data: trend,
              type: 'line',
              borderColor: palette[1],
              backgroundColor: palette[1],
              pointRadius: 0,
              borderWidth: 2,
              tension: 0
            }}
          ]
        }},
        options: {{
          responsive: true,
          maintainAspectRatio: false,
          parsing: false,
          plugins: {{
            legend: {{ position: 'bottom' }},
            tooltip: {{
              callbacks: {{
                label: (ctx) => {{
                  const raw = ctx.raw || {{}};
                  if (raw.label) {{
                    return `${{raw.label}}: x=${{raw.x.toFixed(2)}}, y=${{raw.y.toFixed(2)}}`;
                  }}
                  return `${{ctx.dataset.label}}: x=${{raw.x.toFixed(2)}}, y=${{raw.y.toFixed(2)}}`;
                }}
              }}
            }}
          }},
          scales: {{
            x: {{ title: {{ display: true, text: xLabel }} }},
            y: {{ title: {{ display: true, text: yLabel }} }}
          }}
        }}
      }});
    }}

    function buildTripMixChart() {{
      new Chart(document.getElementById('tripMixChart'), {{
        type: 'bar',
        data: {{
          labels: charts.tripMix.labels,
          datasets: [
            {{ ...charts.tripMix.datasets[0], backgroundColor: '#0b6c88' }},
            {{ ...charts.tripMix.datasets[1], backgroundColor: '#17795b' }},
            {{ ...charts.tripMix.datasets[2], backgroundColor: '#c56024' }}
          ]
        }},
        options: {{
          responsive: true,
          maintainAspectRatio: false,
          plugins: {{ legend: {{ position: 'bottom' }} }},
          scales: {{
            x: {{ stacked: true }},
            y: {{ stacked: true, title: {{ display: true, text: 'Trayectos diarios' }} }}
          }}
        }}
      }});
    }}

    function colorForCorrelation(value) {{
      if (value === null || Number.isNaN(value)) return '#eef3f6';
      const clipped = Math.max(-1, Math.min(1, value));
      if (clipped >= 0) {{
        const alpha = 0.12 + clipped * 0.42;
        return `rgba(23, 121, 91, ${{alpha}})`;
      }}
      const alpha = 0.12 + Math.abs(clipped) * 0.42;
      return `rgba(197, 96, 36, ${{alpha}})`;
    }}

    function buildHeatmap(target, containerId) {{
      const container = document.getElementById(containerId);
      const rows = charts.lagHeatmap.filter(row => row.target === target);
      const metrics = [...new Map(rows.map(row => [row.metric, row.metric_label])).entries()];
      const lags = [-2, -1, 0, 1, 2];

      const header = document.createElement('div');
      header.className = 'heatmap-row';
      header.innerHTML = '<div class="heatmap-label">Métrica</div>' + lags.map(lag => `<div class="heatmap-cell" style="background:#f4f8fa">lag ${{lag}}</div>`).join('');
      container.appendChild(header);

      metrics.forEach(([metric, label]) => {{
        const row = document.createElement('div');
        row.className = 'heatmap-row';
        let html = `<div class="heatmap-label">${{label}}</div>`;
        lags.forEach(lag => {{
          const cell = rows.find(item => item.metric === metric && item.lag_days === lag);
          const value = cell ? cell.pearson : null;
          const text = value === null ? 'NA' : value.toFixed(2);
          html += `<div class="heatmap-cell" style="background:${{colorForCorrelation(value)}}">${{text}}</div>`;
        }});
        row.innerHTML = html;
        container.appendChild(row);
      }});
    }}

    buildLineChart('co2LineChart', charts.labels, charts.co2Line, ['#0b6c88', '#17795b', '#b14678', '#c56024']);
    buildLineChart('no2LineChart', charts.labels, charts.no2Line, ['#c56024', '#0b6c88', '#17795b', '#b14678']);
    buildScatterChart('co2ScatterChart', charts.co2Scatter, charts.co2Trend, ['#17795b', '#0b6c88'], 'Emisiones CO2 inventario', 'CO2 observado');
    buildScatterChart('no2ScatterChart', charts.no2Scatter, charts.no2Trend, ['#c56024', '#0b6c88'], 'Trayectos totales', 'NO2 observado');
    buildTripMixChart();
    buildHeatmap('CO2', 'co2Heatmap');
    buildHeatmap('NO2', 'no2Heatmap');
  </script>
</body>
</html>"""


def build_readme(summary: dict[str, object]) -> str:
    lines = [
        "# Estudio temporal inventario-contaminacion en Cartagena",
        "",
        f"- Periodo: {summary['period_label']}",
        f"- Dias: {summary['n_days']}",
        "",
        "## Archivos principales",
        "- `index.html`: resumen visual del estudio.",
        "- `daily_city_panel.csv`: panel diario ciudad-inventario-sensores.",
        "- `lag_correlations.csv`: correlaciones con retardos entre -2 y +2 dias.",
        "- `model_results.csv`: modelos diarios simples y ajustados por meteorologia.",
        "- `model_meta.csv`: metadatos de cada modelo.",
        "- `tertile_profiles.csv`: promedios de contaminantes por tramos de presion emisora.",
        "- `references/`: bibliografia, BibTeX y notas metodologicas.",
        "",
        "## Idea del estudio",
        "- Trabajar en la escala natural del inventario: dia.",
        "- Comparar el inventario con medias diarias urbanas de CO2 y NO2.",
        "- Mostrar si la senal diaria del inventario aparece como cantidad total, intensidad por viaje o actividad total.",
        "",
        "## Nota",
        "- No se usa O3 en esta fase.",
        "- La interpretacion es temporal y exploratoria, no causal fuerte.",
    ]
    return "\n".join(lines) + "\n"


def write_reference_materials(references_dir: Path, reference_manifest: list[dict[str, object]]) -> None:
    lines = [
        "# Referencias del estudio temporal directo",
        "",
        "Esta carpeta documenta por que el estudio trabaja con agregacion diaria, comparaciones directas del mismo dia y modelos simples ajustados por meteorologia.",
        "",
    ]
    procedure_lines = [
        "# Procedimiento basado en papers",
        "",
        "## 1. Agregacion diaria",
        "- El inventario se resume por dia porque esa es su resolucion natural.",
        "- Los sensores se agregan a medias diarias ciudadanas por parametro.",
        "",
        "## 2. Variables principales",
        "- CO2 y NO2 son los contaminantes objetivo.",
        "- Se comparan relaciones directas del mismo dia entre inventario y sensores.",
        "- Se incluye una lectura auxiliar de actividad diaria con trips_total frente a NO2.",
        "",
        "## 3. Modelos",
        "- Se calculan correlaciones Pearson y Spearman del mismo dia.",
        "- Se ajustan modelos OLS simples y OLS con meteorologia.",
        "",
        "## 4. Lectura",
        "- El estudio estima asociacion temporal diaria, no causalidad fuerte.",
        "",
        "## Papers usados",
    ]
    bibtex_entries: list[str] = []

    for ref, manifest in zip(REFERENCE_CATALOG, reference_manifest):
        local_line = "PDF local no disponible."
        if manifest.get("local_file"):
            local_line = f"PDF local: {Path(manifest['local_file']).name}"
        lines.extend(
            [
                f"## {ref['title']}",
                "",
                f"- Cita: {reference_citation(ref)}",
                f"- Uso en el estudio: {ref['role']}",
                f"- URL: {ref['url']}",
                f"- Estado de descarga: {manifest['download_status']}",
                f"- {local_line}",
                "",
            ]
        )
        procedure_lines.extend(
            [
                f"### {ref['year']} - {ref['title']}",
                f"- Uso en este estudio: {ref['role']}",
                f"- URL: {ref['url']}",
                "",
            ]
        )
        bibtex_entries.append(ref["bibtex"])

    (references_dir / "referencias_y_metodo.md").write_text("\n".join(lines), encoding="utf-8")
    (references_dir / "procedimiento_basado_en_papers.md").write_text("\n".join(procedure_lines), encoding="utf-8")
    (references_dir / "references.bib").write_text("\n\n".join(bibtex_entries) + "\n", encoding="utf-8")
    (references_dir / "download_manifest.json").write_text(
        json.dumps(reference_manifest, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    references_html = """<!doctype html>
<html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Referencias del estudio temporal directo</title>
<style>
body{margin:0;font-family:"Aptos","Segoe UI",sans-serif;background:#f4f7fa;color:#24303a}
main{max-width:980px;margin:0 auto;padding:24px 18px 32px}
.panel{background:#fff;border:1px solid #dde6ed;border-radius:20px;padding:22px;margin-bottom:18px;box-shadow:0 14px 30px rgba(15,38,56,.08)}
h1,h2{margin-top:0} p,li{line-height:1.65;color:#5d6b77} a{color:#0c5f7b;text-decoration:none} a:hover{text-decoration:underline}
</style></head><body><main>
<section class="panel"><h1>Referencias del estudio temporal directo</h1><p>Papers usados para sostener la lectura diaria de emisiones urbanas, meteorologia y contaminacion.</p></section>
""" + "".join(
        (
            "<section class=\"panel\">"
            f"<h2>{html.escape(ref['title'])}</h2>"
            f"<p><strong>Cita:</strong> {html.escape(reference_citation(ref))}</p>"
            f"<p><strong>Uso en el estudio:</strong> {html.escape(ref['role'])}</p>"
            f"<p><a href=\"{html.escape(ref['url'])}\">Fuente web</a>"
            + (
                f" | <a href=\"{Path(manifest['local_file']).name}\">PDF local</a>"
                if manifest.get("local_file")
                else ""
            )
            + "</p></section>"
        )
        for ref, manifest in zip(REFERENCE_CATALOG, reference_manifest)
    ) + "</main></body></html>"
    (references_dir / "index.html").write_text(references_html, encoding="utf-8")

    procedure_html = """<!doctype html>
<html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Procedimiento del estudio temporal directo</title>
<style>
body{margin:0;font-family:"Aptos","Segoe UI",sans-serif;background:#f4f7fa;color:#24303a}
main{max-width:980px;margin:0 auto;padding:24px 18px 32px}
.panel{background:#fff;border:1px solid #dde6ed;border-radius:20px;padding:22px;margin-bottom:18px;box-shadow:0 14px 30px rgba(15,38,56,.08)}
h1,h2{margin-top:0} p,li{line-height:1.65;color:#5d6b77} a{color:#0c5f7b;text-decoration:none} a:hover{text-decoration:underline}
</style></head><body><main>
<section class="panel"><h1>Procedimiento del estudio temporal directo</h1><p>Resumen corto del diseno no espacial usado en este run.</p></section>
<section class="panel"><h2>1. Agregacion</h2><p>Inventario diario y medias diarias de sensores a escala ciudad, sin interpolacion espacial.</p></section>
<section class="panel"><h2>2. Variables</h2><p>El foco se limita a <strong>CO2</strong> y <strong>NO2</strong>. No se usa O3 en esta fase.</p></section>
<section class="panel"><h2>3. Relacion</h2><p>Se comparan pares directos del mismo dia entre inventario y sensores, y se anade una lectura auxiliar de actividad diaria frente a NO2.</p></section>
<section class="panel"><h2>4. Lectura</h2><p>Este estudio estima asociacion temporal diaria, no causalidad fuerte.</p></section>
<section class="panel"><h2>5. Referencias</h2><p>Consulta tambien <a href="index.html">la pagina de referencias</a> y los archivos <code>references.bib</code>, <code>referencias_y_metodo.md</code> y <code>procedimiento_basado_en_papers.md</code>.</p></section>
</main></body></html>"""
    (references_dir / "procedure.html").write_text(procedure_html, encoding="utf-8")


def build_summary_html(
    output_dir: Path,
    daily: pd.DataFrame,
    key_results: pd.DataFrame,
    profiles: pd.DataFrame,
    charts: dict[str, object],
    reference_manifest: list[dict[str, object]],
) -> str:
    references_link = render_layer.relative_link(output_dir, output_dir / "references" / "index.html")
    procedure_link = render_layer.relative_link(output_dir, output_dir / "references" / "procedure.html")
    co2_row = key_results.loc[key_results["relation_id"] == "co2_direct"].iloc[0]
    no2_direct_row = key_results.loc[key_results["relation_id"] == "no2_direct"].iloc[0]
    no2_activity_row = key_results.loc[key_results["relation_id"] == "no2_activity"].iloc[0]
    key_view = key_results.rename(
        columns={
            "relation_label": "Relacion",
            "kind": "Rol",
            "pearson_same_day": "Pearson dia",
            "spearman_same_day": "Spearman dia",
            "raw_coef": "Coef base",
            "raw_p_value": "p base",
            "adjusted_coef": "Coef ajustado",
            "adjusted_p_value": "p ajustado",
            "reading": "Lectura",
        }
    )
    profiles_view = profiles.rename(
        columns={
            "relation_label": "Relacion",
            "group": "Grupo",
            "target_label": "Contaminante",
            "target_mean": "Media observada",
        }
    )
    daily_table = daily.rename(
        columns={
            "day_label": "Dia",
            "emisiones_totales_co2_g": "CO2 inventario",
            "emisiones_totales_nox_g": "NOx inventario",
            "trips_total": "Trayectos",
            "CO2": "CO2 observado",
            "NO2": "NO2 observado",
            "temperature": "Temperatura",
            "relativehumidity": "Humedad",
            "atmosphericpressure": "Presion",
            "precipitation": "Precipitacion",
        }
    )

    reference_items: list[str] = []
    for manifest in reference_manifest:
        local_html = ""
        if manifest.get("local_file"):
            local_html = f" | <a href=\"{render_layer.relative_link(output_dir, Path(manifest['local_file']))}\">PDF local</a>"
        reference_items.append(
            "<li>"
            f"<strong>{html.escape(manifest['citation'])}</strong><br>"
            f"{html.escape(manifest['role'])}<br>"
            f"<a href=\"{html.escape(manifest['url'])}\">Fuente web</a>{local_html}"
            "</li>"
        )

    charts_json = json.dumps(charts, ensure_ascii=False)
    return f"""<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Estudio temporal directo inventario-contaminacion</title>
  <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.2"></script>
  <style>
    :root {{
      --panel: rgba(255,255,255,0.95);
      --ink: #22303b;
      --muted: #5d6b77;
      --line: #d7e1e8;
      --blue: #0b6c88;
      --green: #17795b;
      --orange: #c56024;
      --pink: #b14678;
      --shadow: 0 20px 44px rgba(15, 38, 56, 0.10);
    }}
    body {{
      margin: 0;
      color: var(--ink);
      font-family: "Aptos", "Segoe UI", "Helvetica Neue", sans-serif;
      background:
        radial-gradient(circle at top left, rgba(11, 108, 136, 0.12), transparent 24%),
        radial-gradient(circle at 88% 10%, rgba(197, 96, 36, 0.10), transparent 22%),
        linear-gradient(180deg, #f7f9fb 0%, #eef3f6 100%);
    }}
    main {{ max-width: 1360px; margin: 0 auto; padding: 24px 18px 36px; }}
    .panel {{
      background: var(--panel);
      border: 1px solid rgba(20,53,74,.08);
      border-radius: 26px;
      padding: 24px;
      margin-bottom: 20px;
      box-shadow: var(--shadow);
    }}
    .eyebrow {{
      display:inline-flex; padding:8px 12px; border-radius:999px; background:rgba(11,108,136,.10);
      color:var(--blue); font-size:12px; font-weight:800; letter-spacing:.10em; text-transform:uppercase; margin-bottom:12px;
    }}
    h1,h2,h3{{margin-top:0}}
    h1{{font-size:42px; line-height:1.02; letter-spacing:-.04em; margin-bottom:10px; color:var(--blue)}}
    h2{{font-size:24px; letter-spacing:-.02em; margin-bottom:12px}}
    p, li{{color:var(--muted); line-height:1.65}}
    .hero-grid{{display:grid; grid-template-columns:minmax(0,1.45fr) minmax(340px,.95fr); gap:22px; align-items:start}}
    .kpi-grid{{display:grid; grid-template-columns:repeat(2,minmax(0,1fr)); gap:14px}}
    .kpi{{border:1px solid rgba(20,53,74,.08); border-radius:18px; padding:16px; background:rgba(255,255,255,.84)}}
    .kpi span{{display:block; font-size:11px; letter-spacing:.10em; text-transform:uppercase; color:var(--muted); font-weight:800; margin-bottom:10px}}
    .kpi strong{{display:block; font-size:32px; line-height:1; color:var(--blue); margin-bottom:8px}}
    .pill-row{{display:flex; gap:10px; flex-wrap:wrap; margin-top:14px}}
    .pill{{display:inline-flex; align-items:center; padding:9px 12px; border-radius:999px; border:1px solid var(--line); background:#fff; font-size:13px; color:var(--muted); font-weight:700}}
    .pill strong{{color:var(--ink); margin-left:6px}}
    .story-grid{{display:grid; grid-template-columns:repeat(3,minmax(0,1fr)); gap:16px}}
    .story{{border-radius:18px; padding:18px; border:1px solid rgba(20,53,74,.08); background:linear-gradient(180deg,#fff 0%, #f5f8fb 100%)}}
    .story.co2{{border-left:6px solid var(--green)}}
    .story.no2{{border-left:6px solid var(--orange)}}
    .story.support{{border-left:6px solid var(--pink)}}
    .tag{{font-size:11px; font-weight:800; letter-spacing:.12em; text-transform:uppercase; color:var(--muted); margin-bottom:10px}}
    .story strong{{display:block; font-size:24px; margin-bottom:8px}}
    .formula{{padding:16px; border-radius:16px; background:#f7fafc; border:1px solid var(--line); overflow-x:auto; font-family:"Cascadia Code","Consolas",monospace; font-size:13px; color:#33404a; line-height:1.6; white-space:pre-wrap}}
    .three-col{{display:grid; grid-template-columns:repeat(3,minmax(0,1fr)); gap:18px}}
    .chart-card{{border:1px solid rgba(20,53,74,.08); border-radius:18px; padding:16px; background:#fff}}
    .chart-shell{{position:relative; height:320px; min-height:320px}}
    .chart-shell.tall{{height:340px; min-height:340px}}
    .chart-shell canvas{{position:absolute; inset:0; width:100% !important; height:100% !important; display:block}}
    .stats-table{{width:100%; border-collapse:collapse; font-size:14px}}
    .stats-table th,.stats-table td{{padding:10px 12px; border-bottom:1px solid var(--line); text-align:left; vertical-align:top}}
    .stats-table th{{font-size:11px; letter-spacing:.10em; text-transform:uppercase; color:var(--muted); background:rgba(247,250,252,.92)}}
    .callout{{padding:16px 18px; border-radius:16px; background:#fff; border:1px dashed rgba(11,108,136,.28); color:var(--muted)}}
    ul.refs{{margin:0; padding-left:20px}} ul.refs li{{margin-bottom:14px}}
    a{{color:var(--blue); text-decoration:none}} a:hover{{text-decoration:underline}}
    @media (max-width:1180px){{.three-col{{grid-template-columns:1fr}}}}
    @media (max-width:1040px){{.hero-grid,.story-grid{{grid-template-columns:1fr}}}}
    @media (max-width:720px){{main{{padding:14px 10px 28px}} .panel{{padding:18px; border-radius:18px}} h1{{font-size:32px}} .kpi-grid{{grid-template-columns:1fr}} }}
  </style>
</head>
<body>
  <main>
    <section class="panel">
      <span class="eyebrow">Estudio temporal directo</span>
      <div class="hero-grid">
        <div>
          <h1>Relacion diaria entre inventario y CO2/NO2</h1>
          <p>Esta version se ha rehecho para que la lectura sea directa. Solo se muestran relaciones del mismo dia con sentido claro: <strong>CO2 inventario vs CO2 sensores</strong>, <strong>NOx inventario vs NO2 sensores</strong> y, como apoyo, <strong>actividad diaria del inventario vs NO2</strong>.</p>
          <div class="pill-row">
            <div class="pill">Periodo<strong>{html.escape(daily['day_label'].iloc[0])} a {html.escape(daily['day_label'].iloc[-1])}</strong></div>
            <div class="pill">Dias solapados<strong>{format_short(len(daily))}</strong></div>
            <div class="pill">Resolucion inventario<strong>diaria</strong></div>
            <div class="pill">O3<strong>excluido</strong></div>
          </div>
        </div>
        <div class="kpi-grid">
          <div class="kpi">
            <span>CO2 directo</span>
            <strong>{format_short(co2_row['pearson_same_day'])}</strong>
            <p>Correlacion del mismo dia entre <code>emisiones_totales_co2_g</code> y CO2 observado.</p>
          </div>
          <div class="kpi">
            <span>NO2 directo</span>
            <strong>{format_short(no2_direct_row['pearson_same_day'])}</strong>
            <p>Correlacion del mismo dia entre <code>emisiones_totales_nox_g</code> y NO2 observado.</p>
          </div>
          <div class="kpi">
            <span>NO2 actividad</span>
            <strong>{format_short(no2_activity_row['pearson_same_day'])}</strong>
            <p>Correlacion del mismo dia entre <code>trips_total</code> y NO2 observado.</p>
          </div>
          <div class="kpi">
            <span>Lectura</span>
            <strong>{html.escape(str(no2_activity_row['reading']))}</strong>
            <p>Con 10 dias, la senal mas visible aparece en NO2 cuando el inventario se lee como actividad diaria.</p>
          </div>
        </div>
      </div>
    </section>

    <section class="panel">
      <h2>Lectura principal</h2>
      <div class="story-grid">
        <div class="story co2">
          <div class="tag">CO2</div>
          <strong>La relacion directa CO2-inventario no sale clara</strong>
          <p>La correlacion del mismo dia es <strong>{format_short(co2_row['pearson_same_day'])}</strong>. En este corte tan corto, el CO2 ambiente no sigue de forma limpia la masa diaria total del inventario.</p>
        </div>
        <div class="story no2">
          <div class="tag">NO2</div>
          <strong>La relacion directa NOx-NO2 es positiva, pero debil</strong>
          <p>La correlacion del mismo dia entre NOx del inventario y NO2 observado es <strong>{format_short(no2_direct_row['pearson_same_day'])}</strong>. Hay una senal compatible, pero todavia corta para una conclusion fuerte.</p>
        </div>
        <div class="story support">
          <div class="tag">Apoyo</div>
          <strong>NO2 sigue mejor la actividad diaria que la masa total</strong>
          <p>La relacion mas visible del estudio es <strong>trayectos totales vs NO2</strong>, con correlacion <strong>{format_short(no2_activity_row['pearson_same_day'])}</strong>. Eso hace el relato mas claro con lo que tienes hoy.</p>
        </div>
      </div>
    </section>

    <section class="panel">
      <h2>Como se ha hecho</h2>
      <div class="formula">1. Inventario diario
I_d = sum(emisiones_d, trayectos_d, kms_d)

2. Sensores diarios ciudad
C_d = media_estaciones(contaminante_d)
M_d = media_estaciones(meteorologia_d)

3. Pares directos del mismo dia
CO2_d ~ emisiones_totales_co2_g_d
NO2_d ~ emisiones_totales_nox_g_d

4. Lectura auxiliar
NO2_d ~ trips_total_d

5. Comprobacion ajustada
contaminante_d = alpha + beta * inventario_d + gamma * meteorologia_d + error_d

El objetivo es una lectura temporal simple y defendible, no un modelo causal duro.</div>
      <p class="callout">La metodologia y las referencias estan en <a href="{html.escape(procedure_link)}">procedure.html</a> y <a href="{html.escape(references_link)}">index.html</a>.</p>
    </section>

    <section class="panel">
      <h2>Series diarias normalizadas</h2>
      <div class="three-col">
        <div class="chart-card">
          <h3>CO2 inventario vs CO2 sensores</h3>
          <div class="chart-shell"><canvas id="co2LineChart"></canvas></div>
        </div>
        <div class="chart-card">
          <h3>NOx inventario vs NO2 sensores</h3>
          <div class="chart-shell"><canvas id="no2DirectLineChart"></canvas></div>
        </div>
        <div class="chart-card">
          <h3>Actividad del inventario vs NO2</h3>
          <div class="chart-shell"><canvas id="no2ActivityLineChart"></canvas></div>
        </div>
      </div>
    </section>

    <section class="panel">
      <h2>Scatters diarios</h2>
      <div class="three-col">
        <div class="chart-card">
          <h3>CO2 observado vs CO2 inventario</h3>
          <div class="chart-shell"><canvas id="co2ScatterChart"></canvas></div>
        </div>
        <div class="chart-card">
          <h3>NO2 observado vs NOx inventario</h3>
          <div class="chart-shell"><canvas id="no2DirectScatterChart"></canvas></div>
        </div>
        <div class="chart-card">
          <h3>NO2 observado vs trayectos totales</h3>
          <div class="chart-shell"><canvas id="no2ActivityScatterChart"></canvas></div>
        </div>
      </div>
    </section>

    <section class="panel">
      <h2>Composicion diaria del inventario</h2>
      <div class="chart-card">
        <h3>Trayectos counted, interior y salidas</h3>
        <div class="chart-shell tall"><canvas id="tripMixChart"></canvas></div>
      </div>
    </section>

    <section class="panel">
      <h2>Resultados clave</h2>
      {dataframe_html(key_view, ['Relacion', 'Rol', 'Pearson dia', 'Spearman dia', 'Coef base', 'p base', 'Coef ajustado', 'p ajustado', 'Lectura'])}
    </section>

    <section class="panel">
      <h2>Promedios por dias bajos, medios y altos</h2>
      {dataframe_html(profiles_view, ['Relacion', 'Grupo', 'Contaminante', 'Media observada'])}
    </section>

    <section class="panel">
      <h2>Panel diario usado</h2>
      {dataframe_html(daily_table, ['Dia', 'CO2 inventario', 'NOx inventario', 'Trayectos', 'CO2 observado', 'NO2 observado', 'Temperatura', 'Humedad', 'Presion', 'Precipitacion'])}
    </section>

    <section class="panel">
      <h2>Referencias incluidas</h2>
      <ul class="refs">
        {''.join(reference_items)}
      </ul>
    </section>
  </main>

  <script>
    const charts = {charts_json};

    function lineDatasets(series, palette) {{
      return series.map((item, idx) => ({{
        label: item.label,
        data: item.data,
        borderColor: palette[idx % palette.length],
        backgroundColor: palette[idx % palette.length],
        pointRadius: 4,
        borderWidth: 2.5,
        tension: 0.25,
        fill: false
      }}));
    }}

    function buildLineChart(id, labels, series, palette) {{
      new Chart(document.getElementById(id), {{
        type: 'line',
        data: {{
          labels,
          datasets: lineDatasets(series, palette)
        }},
        options: {{
          responsive: true,
          maintainAspectRatio: false,
          plugins: {{
            legend: {{ position: 'bottom' }}
          }},
          scales: {{
            y: {{ title: {{ display: true, text: 'z-score diario' }} }}
          }}
        }}
      }});
    }}

    function buildScatterChart(id, points, trend, palette, xLabel, yLabel) {{
      new Chart(document.getElementById(id), {{
        type: 'scatter',
        data: {{
          datasets: [
            {{
              label: 'Dias',
              data: points,
              backgroundColor: palette[0],
              borderColor: palette[0],
              pointRadius: 5
            }},
            {{
              label: 'Ajuste lineal',
              data: trend,
              type: 'line',
              borderColor: palette[1],
              backgroundColor: palette[1],
              pointRadius: 0,
              borderWidth: 2,
              tension: 0
            }}
          ]
        }},
        options: {{
          responsive: true,
          maintainAspectRatio: false,
          parsing: false,
          plugins: {{
            legend: {{ position: 'bottom' }},
            tooltip: {{
              callbacks: {{
                label: (ctx) => {{
                  const raw = ctx.raw || {{}};
                  if (raw.label) {{
                    return `${{raw.label}}: x=${{raw.x.toFixed(2)}}, y=${{raw.y.toFixed(2)}}`;
                  }}
                  return `${{ctx.dataset.label}}: x=${{raw.x.toFixed(2)}}, y=${{raw.y.toFixed(2)}}`;
                }}
              }}
            }}
          }},
          scales: {{
            x: {{ title: {{ display: true, text: xLabel }} }},
            y: {{ title: {{ display: true, text: yLabel }} }}
          }}
        }}
      }});
    }}

    function buildTripMixChart() {{
      new Chart(document.getElementById('tripMixChart'), {{
        type: 'bar',
        data: {{
          labels: charts.tripMix.labels,
          datasets: [
            {{ ...charts.tripMix.datasets[0], backgroundColor: '#0b6c88' }},
            {{ ...charts.tripMix.datasets[1], backgroundColor: '#17795b' }},
            {{ ...charts.tripMix.datasets[2], backgroundColor: '#c56024' }}
          ]
        }},
        options: {{
          responsive: true,
          maintainAspectRatio: false,
          plugins: {{ legend: {{ position: 'bottom' }} }},
          scales: {{
            x: {{ stacked: true }},
            y: {{ stacked: true, title: {{ display: true, text: 'Trayectos diarios' }} }}
          }}
        }}
      }});
    }}

    buildLineChart('co2LineChart', charts.labels, charts.co2DirectLine, ['#17795b', '#0b6c88']);
    buildLineChart('no2DirectLineChart', charts.labels, charts.no2DirectLine, ['#c56024', '#0b6c88']);
    buildLineChart('no2ActivityLineChart', charts.labels, charts.no2ActivityLine, ['#b14678', '#0b6c88']);
    buildScatterChart('co2ScatterChart', charts.co2DirectScatter, charts.co2DirectTrend, ['#17795b', '#0b6c88'], 'Emisiones CO2 inventario', 'CO2 observado');
    buildScatterChart('no2DirectScatterChart', charts.no2DirectScatter, charts.no2DirectTrend, ['#c56024', '#0b6c88'], 'Emisiones NOx inventario', 'NO2 observado');
    buildScatterChart('no2ActivityScatterChart', charts.no2ActivityScatter, charts.no2ActivityTrend, ['#b14678', '#0b6c88'], 'Trayectos totales', 'NO2 observado');
    buildTripMixChart();
  </script>
</body>
</html>"""


def build_readme(summary: dict[str, object]) -> str:
    lines = [
        "# Estudio temporal directo inventario-contaminacion en Cartagena",
        "",
        f"- Periodo: {summary['period_label']}",
        f"- Dias: {summary['n_days']}",
        "",
        "## Archivos principales",
        "- `index.html`: resumen visual y directo del estudio.",
        "- `daily_city_panel.csv`: panel diario ciudad-inventario-sensores.",
        "- `key_results.csv`: tabla corta con relaciones clave del mismo dia.",
        "- `model_results.csv`: modelos OLS simples y ajustados por meteorologia.",
        "- `model_meta.csv`: metadatos por modelo.",
        "- `exposure_profiles.csv`: medias observadas por dias bajos, medios y altos.",
        "- `references/`: bibliografia, BibTeX y notas metodologicas.",
        "",
        "## Idea del estudio",
        "- Trabajar en la escala natural del inventario: dia.",
        "- Comparar pares directos del mismo dia entre inventario y sensores.",
        "- Mantener una sola lectura auxiliar: actividad diaria frente a NO2.",
        "",
        "## Nota",
        "- No se usa O3 en esta fase.",
        "- La interpretacion es temporal y exploratoria, no causal fuerte.",
    ]
    return "\n".join(lines) + "\n"


def main() -> None:
    args = parse_args()
    output_dir = args.output_dir
    references_dir = output_dir / "references"
    ensure_dir(output_dir)
    ensure_dir(references_dir)

    inventory_daily = load_inventory_daily(args.inventory_csv)
    city_daily, city_meta = load_city_daily(args.sensor_csv, args.timezone)
    daily = merge_daily(inventory_daily, city_daily, city_meta)
    profiles = exposure_profiles(daily)

    model_frames: list[pd.DataFrame] = []
    meta_rows: list[dict[str, object]] = []
    for spec in MODEL_SPECS:
        frame, meta = fit_model(daily, spec)
        model_frames.append(frame)
        meta_rows.append(meta)
    model_results = pd.concat(model_frames, ignore_index=True)
    model_meta = pd.DataFrame(meta_rows)
    key_results = same_day_relationships(daily, model_results)

    charts = build_chart_payload(daily, profiles)
    reference_manifest = download_reference_pdfs(references_dir)
    write_reference_materials(references_dir, reference_manifest)

    stale_outputs = [output_dir / "lag_correlations.csv", output_dir / "tertile_profiles.csv"]
    for stale_path in stale_outputs:
        if stale_path.exists():
            stale_path.unlink()

    summary = {
        "period_label": f"{daily['day_label'].iloc[0]} a {daily['day_label'].iloc[-1]}",
        "n_days": int(len(daily)),
        "outputs": {
            "daily_city_panel_csv": str(output_dir / "daily_city_panel.csv"),
            "key_results_csv": str(output_dir / "key_results.csv"),
            "model_results_csv": str(output_dir / "model_results.csv"),
            "model_meta_csv": str(output_dir / "model_meta.csv"),
            "exposure_profiles_csv": str(output_dir / "exposure_profiles.csv"),
            "summary_json": str(output_dir / "study_summary.json"),
            "summary_html": str(output_dir / "index.html"),
        },
    }

    daily.to_csv(output_dir / "daily_city_panel.csv", index=False)
    key_results.to_csv(output_dir / "key_results.csv", index=False)
    model_results.to_csv(output_dir / "model_results.csv", index=False)
    model_meta.to_csv(output_dir / "model_meta.csv", index=False)
    profiles.to_csv(output_dir / "exposure_profiles.csv", index=False)
    (output_dir / "charts_data.json").write_text(json.dumps(charts, ensure_ascii=False, indent=2), encoding="utf-8")
    (output_dir / "study_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    (output_dir / "README.md").write_text(build_readme(summary), encoding="utf-8")
    (output_dir / "index.html").write_text(
        build_summary_html(
            output_dir=output_dir,
            daily=daily,
            key_results=key_results,
            profiles=profiles,
            charts=charts,
            reference_manifest=reference_manifest,
        ),
        encoding="utf-8",
    )

    print(f"Estudio temporal guardado en: {output_dir}")


if __name__ == "__main__":
    main()
