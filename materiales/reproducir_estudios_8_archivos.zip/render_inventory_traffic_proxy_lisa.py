from __future__ import annotations

import argparse
import sys
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parent
PIPELINE_ROOT = PROJECT_ROOT / ".runtime" / "Definitivo_Limpio"
if str(PIPELINE_ROOT) not in sys.path:
    sys.path.insert(0, str(PIPELINE_ROOT))

from pipeline import render_layer


STUDY_ROOT = PROJECT_ROOT
DEFAULT_RESULTS_DIR = STUDY_ROOT / "results" / "inventario_traffic_proxy_lisa"
PROXY_LABELS = {
    "nox_proxy_trafico": "Proxy NOx trafico",
    "co2_proxy_trafico": "Proxy CO2 trafico",
}
PROXY_NOTES = {
    "nox_proxy_trafico": [
        "Proxy de emision construido como coches_total por hora multiplicado por el factor diario medio de NOx del inventario.",
        "La estructura espacial la aporta el trafico observado; el inventario aporta la intensidad de emision diaria.",
    ],
    "co2_proxy_trafico": [
        "Proxy de emision construido como coches_total por hora multiplicado por el factor diario medio de CO2 del inventario.",
        "La estructura espacial la aporta el trafico observado; el inventario aporta la intensidad de emision diaria.",
    ],
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Genera mapas HTML interactivos a partir de los resultados creados por "
            "build_inventory_traffic_proxy_lisa.py."
        )
    )
    parser.add_argument(
        "--results-dir",
        type=Path,
        default=DEFAULT_RESULTS_DIR,
        help="Carpeta con sector_results.geojson, run_summary.json y los CSV globales.",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=None,
        help="Carpeta de salida para los HTML. Por defecto usa <results-dir>/maps.",
    )
    return parser.parse_args()


def apply_proxy_labels() -> None:
    original_value_scale_label = render_layer.value_scale_label
    original_value_scale_notes = render_layer.value_scale_notes

    def custom_label(column: str) -> str:
        return PROXY_LABELS.get(column, original_value_scale_label(column))

    def custom_notes(column: str, values=None) -> list[str]:
        if column in PROXY_NOTES:
            return PROXY_NOTES[column]
        return original_value_scale_notes(column, values)

    render_layer.value_scale_label = custom_label
    render_layer.value_scale_notes = custom_notes


def main() -> None:
    args = parse_args()
    output_dir = args.output_dir or (args.results_dir / "maps")
    render_layer.ensure_dir(output_dir)

    apply_proxy_labels()
    sectors, summary, univariate, bivariate = render_layer.load_inputs(args.results_dir)
    inputs = summary.setdefault("inputs", {})
    # Force the mean/univariate map selector to focus on the inventory-to-sector proxies.
    inputs["univariate_variables"] = list(PROXY_LABELS.keys())
    render_layer.build_map_set(
        sectors=sectors,
        summary=summary,
        univariate=univariate,
        bivariate=bivariate,
        output_dir=output_dir,
    )
    print(f"Mapas HTML guardados en: {output_dir}")


if __name__ == "__main__":
    main()
