from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import geopandas as gpd
import numpy as np
import pandas as pd


PROJECT_ROOT = Path(__file__).resolve().parent
PIPELINE_ROOT = PROJECT_ROOT / ".runtime" / "Definitivo_Limpio"
if str(PIPELINE_ROOT) not in sys.path:
    sys.path.insert(0, str(PIPELINE_ROOT))

from pipeline import qc_layer, spatial_layer


STUDY_ROOT = PROJECT_ROOT
DEFAULT_SENSOR_CSV = STUDY_ROOT / "combined_flags.csv"
DEFAULT_INVENTORY_CSV = STUDY_ROOT / "inventario_cartagena_maestro.csv"
DEFAULT_SECTORS = PIPELINE_ROOT / "data_static" / "cartagena_census_sections.geojson"
DEFAULT_OUTPUT_DIR = STUDY_ROOT / "results" / "inventario_trip_proxy_lisa"
DEFAULT_SENSOR_VARIABLES = ["CO", "NO2", "O3", "SO2", "PM10", "PM25", "PM1", "VOC", "CO2"]
DEFAULT_TRAFFIC_PARAM = "coches_total"
DEFAULT_NOX_TARGETS = ["NO2", "PM10", "PM25", "VOC"]
DEFAULT_CO2_TARGETS = ["CO2"]
DEFAULT_ZBE_SOURCE = "official_sector_ids"
DEFAULT_MAP_VARIABLES = [
    "nox_proxy_counted",
    "nox_proxy_interior",
    "nox_proxy_salidas",
    "nox_proxy_total",
    "co2_proxy_counted",
    "co2_proxy_interior",
    "co2_proxy_salidas",
    "co2_proxy_total",
]
INVENTORY_TRIP_COLUMNS = [
    "trayectos_inician_y_finalizan",
    "trayectos_inician",
    "trayectos_finalizan",
    "trayectos_cruzan",
]
WORK_CRS = spatial_layer.WORK_CRS
SECTOR_ZONE_INTERIOR = "interior_zbe"
SECTOR_ZONE_BORDER = "borde_zbe"
SECTOR_ZONE_EXTERIOR = "exterior_cercano"
SECTOR_ZONE_OUTSIDE = "fuera_modelo_salidas"
OFFICIAL_ZBE_INTERIOR_SECTOR_IDS = [
    "3001601002",
    "3001601004",
    "3001602002",
    "3001602005",
    "3001602006",
    "3001602011",
    "3001603001",
    "3001603002",
    "3001603003",
    "3001603006",
    "3001603010",
    "3001603013",
    "3001603014",
    "3001603019",
    "3001603020",
    "3001603022",
    "3001603023",
    "3001603028",
    "3001603029",
    "3001603032",
    "3001603035",
    "3001603036",
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Construye proxies sectoriales diferenciando trafico contado por sensores, "
            "trayectos internos a la ZBE y salidas desde la ZBE; despues ejecuta "
            "un analisis LISA bivariante con counted y total."
        )
    )
    parser.add_argument("--sensor-csv", type=Path, default=DEFAULT_SENSOR_CSV, help="CSV QC compacto con sensores.")
    parser.add_argument(
        "--inventory-csv",
        type=Path,
        default=DEFAULT_INVENTORY_CSV,
        help="CSV maestro del inventario de vehiculos conectados.",
    )
    parser.add_argument(
        "--sectors",
        type=Path,
        default=DEFAULT_SECTORS,
        help="GeoJSON de secciones censales usado por el estudio.",
    )
    parser.add_argument(
        "--sensor-variables",
        nargs="+",
        default=DEFAULT_SENSOR_VARIABLES,
        help="Contaminantes de sensores que entran al estudio sectorial.",
    )
    parser.add_argument(
        "--traffic-param",
        default=DEFAULT_TRAFFIC_PARAM,
        help="Parametro de trafico usado para construir el soporte espacial de las capas.",
    )
    parser.add_argument(
        "--nox-targets",
        nargs="+",
        default=DEFAULT_NOX_TARGETS,
        help="Variables objetivo comparadas contra las capas NOx counted y total.",
    )
    parser.add_argument(
        "--co2-targets",
        nargs="+",
        default=DEFAULT_CO2_TARGETS,
        help="Variables objetivo comparadas contra las capas CO2 counted y total.",
    )
    parser.add_argument(
        "--zbe-source",
        choices=["official_sector_ids", "sensor_hull"],
        default=DEFAULT_ZBE_SOURCE,
        help=(
            "Fuente espacial para definir la ZBE interior. "
            "'official_sector_ids' usa una mascara oficial aproximada por secciones; "
            "'sensor_hull' usa el casco convexo de sensores de entrada."
        ),
    )
    parser.add_argument(
        "--daily-hours",
        type=float,
        default=1.0,
        help="Divisor temporal aplicado a las emisiones diarias antes del reparto espacial. Default: 1.0 (media diaria).",
    )
    parser.add_argument(
        "--zbe-polygon-buffer-m",
        type=float,
        default=40.0,
        help="Buffer aplicado al casco convexo de sensores de entrada para definir la ZBE funcional.",
    )
    parser.add_argument(
        "--exit-border-buffer-m",
        type=float,
        default=250.0,
        help="Distancia desde la ZBE funcional para clasificar sectores de borde.",
    )
    parser.add_argument(
        "--exit-outer-buffer-m",
        type=float,
        default=900.0,
        help="Distancia maxima desde la ZBE funcional para clasificar sectores exteriores cercanos.",
    )
    parser.add_argument(
        "--exit-border-share",
        type=float,
        default=0.65,
        help="Peso total asignado a sectores de borde al repartir las salidas.",
    )
    parser.add_argument(
        "--exit-exterior-share",
        type=float,
        default=0.35,
        help="Peso total asignado a sectores exteriores al repartir las salidas.",
    )
    parser.add_argument(
        "--value-column",
        default=spatial_layer.DEFAULT_VALUE_COLUMN,
        help="Columna numerica del CSV de sensores usada como valor de analisis.",
    )
    parser.add_argument(
        "--sector-id",
        default=spatial_layer.DEFAULT_SECTOR_ID,
        help="Campo identificador del sector. Default: cusec",
    )
    parser.add_argument(
        "--sector-core-radius-km",
        type=float,
        default=spatial_layer.DEFAULT_SECTOR_CORE_RADIUS_KM,
        help="Radio central para definir el area de estudio sectorial.",
    )
    parser.add_argument(
        "--sector-study-buffer-m",
        type=float,
        default=spatial_layer.DEFAULT_SECTOR_STUDY_BUFFER_M,
        help="Buffer del casco convexo de sensores de aire.",
    )
    parser.add_argument(
        "--sector-max-nearest-sensor-km",
        type=float,
        default=spatial_layer.DEFAULT_SECTOR_MAX_NEAREST_SENSOR_KM,
        help="Distancia maxima al sensor de aire mas cercano.",
    )
    parser.add_argument(
        "--sector-influence-radius-km",
        type=float,
        default=spatial_layer.DEFAULT_SECTOR_INFLUENCE_RADIUS_KM,
        help="Radio local usado para interpolar el soporte de trafico a centroides sectoriales.",
    )
    parser.add_argument(
        "--sector-min-local-stations",
        type=int,
        default=spatial_layer.DEFAULT_SECTOR_MIN_LOCAL_STATIONS,
        help="Numero minimo de estaciones locales por sector y variable.",
    )
    parser.add_argument(
        "--sector-idw-power",
        type=float,
        default=spatial_layer.DEFAULT_SECTOR_IDW_POWER,
        help="Exponente IDW para interpolar a centroides sectoriales.",
    )
    parser.add_argument(
        "--timezone",
        default=spatial_layer.DEFAULT_TIMEZONE,
        help="Huso local usado para construir dias de estudio.",
    )
    parser.add_argument("--start-date", default=None, help="Fecha local inicial opcional YYYY-MM-DD.")
    parser.add_argument("--end-date", default=None, help="Fecha local final opcional YYYY-MM-DD.")
    parser.add_argument(
        "--permutations",
        type=int,
        default=spatial_layer.DEFAULT_PERMUTATIONS,
        help="Numero de permutaciones para Moran/LISA.",
    )
    parser.add_argument(
        "--p-threshold",
        type=float,
        default=spatial_layer.DEFAULT_P_THRESHOLD,
        help="Umbral p para etiquetar clusters locales.",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=DEFAULT_OUTPUT_DIR,
        help="Carpeta de salida para CSV, GeoJSON y resumen JSON.",
    )
    return parser.parse_args()


def load_inventory_daily_split(
    path: Path,
    timezone: str,
    start_date: pd.Timestamp | None,
    end_date: pd.Timestamp | None,
) -> pd.DataFrame:
    usecols = ["fecha", "emisiones_totales_nox_g", "emisiones_totales_co2_g"] + INVENTORY_TRIP_COLUMNS
    frame = pd.read_csv(path, usecols=usecols)
    frame["local_day"] = pd.to_datetime(frame["fecha"], errors="coerce")
    frame = frame.dropna(subset=["local_day"]).copy()
    frame["local_day"] = frame["local_day"].dt.tz_localize(timezone).dt.normalize()

    for column in INVENTORY_TRIP_COLUMNS + ["emisiones_totales_nox_g", "emisiones_totales_co2_g"]:
        frame[column] = pd.to_numeric(frame[column], errors="coerce").fillna(0.0)

    frame["trips_counted"] = frame["trayectos_finalizan"] + frame["trayectos_cruzan"]
    frame["trips_interior"] = frame["trayectos_inician_y_finalizan"]
    frame["trips_salidas"] = frame["trayectos_inician"]
    frame["trips_total"] = frame["trips_counted"] + frame["trips_interior"] + frame["trips_salidas"]
    frame = frame.loc[frame["trips_total"] > 0].copy()

    if start_date is not None:
        frame = frame.loc[frame["local_day"] >= start_date.normalize()]
    if end_date is not None:
        frame = frame.loc[frame["local_day"] <= end_date.normalize()]

    if frame.empty:
        raise ValueError("Inventory CSV does not contain usable rows inside the requested date range.")

    daily = (
        frame.groupby("local_day", as_index=False)
        .agg(
            trips_counted=("trips_counted", "sum"),
            trips_interior=("trips_interior", "sum"),
            trips_salidas=("trips_salidas", "sum"),
            emisiones_totales_nox_g=("emisiones_totales_nox_g", "sum"),
            emisiones_totales_co2_g=("emisiones_totales_co2_g", "sum"),
            vehiculos=("trips_total", "size"),
        )
        .sort_values("local_day")
        .reset_index(drop=True)
    )
    daily["trips_total"] = daily["trips_counted"] + daily["trips_interior"] + daily["trips_salidas"]

    for gas in ["nox", "co2"]:
        total_column = f"emisiones_totales_{gas}_g"
        for group in ["counted", "interior", "salidas"]:
            trip_column = f"trips_{group}"
            share_column = f"share_{group}"
            emissions_column = f"emisiones_{gas}_{group}_g"
            daily[share_column] = np.divide(
                daily[trip_column],
                daily["trips_total"],
                out=np.zeros(len(daily), dtype=float),
                where=daily["trips_total"] > 0,
            )
            daily[emissions_column] = daily[total_column] * daily[share_column]

        for group in ["counted", "interior", "salidas", "total"]:
            if group == "total":
                emissions_series = daily[total_column]
                trips_series = daily["trips_total"]
            else:
                emissions_series = daily[f"emisiones_{gas}_{group}_g"]
                trips_series = daily[f"trips_{group}"]

            factor_column = f"factor_{gas}_g_por_viaje_{group}"
            daily[factor_column] = np.divide(
                emissions_series,
                trips_series,
                out=np.zeros(len(daily), dtype=float),
                where=trips_series > 0,
            )

    return daily


def overlap_days(sensor_daily: pd.DataFrame, inventory_daily: pd.DataFrame) -> pd.DatetimeIndex:
    sensor_days = pd.DatetimeIndex(sensor_daily["local_day"].drop_duplicates().sort_values())
    inventory_days = pd.DatetimeIndex(inventory_daily["local_day"].drop_duplicates().sort_values())
    return sensor_days.intersection(inventory_days).sort_values()


def bounds_from_days(days: pd.DatetimeIndex) -> tuple[pd.Timestamp, pd.Timestamp]:
    start_day = pd.Timestamp(days.min())
    end_day = pd.Timestamp(days.max()) + pd.Timedelta(days=1) - pd.Timedelta(microseconds=1)
    return start_day, end_day


def build_zbe_geometry(
    sectors: gpd.GeoDataFrame,
    sector_id: str,
    traffic_daily: pd.DataFrame,
    zbe_source: str,
    zbe_polygon_buffer_m: float,
) -> tuple[gpd.GeoDataFrame, dict[str, object]]:
    if zbe_source == "official_sector_ids":
        requested_ids = [str(value) for value in OFFICIAL_ZBE_INTERIOR_SECTOR_IDS]
        requested_set = set(requested_ids)
        selected = sectors.loc[sectors[sector_id].astype(str).isin(requested_set)].copy()
        if selected.empty:
            raise ValueError("La mascara oficial ZBE por sectores no intersecta ningun sector del estudio.")

        missing_ids = [value for value in requested_ids if value not in set(selected[sector_id].astype(str))]
        selected_proj = selected.to_crs(WORK_CRS)
        zbe_geometry = selected_proj.geometry.union_all()
        zbe_frame = gpd.GeoDataFrame(
            {
                "kind": ["zbe_oficial_aproximada"],
                "selection_mode": ["official_sector_ids"],
                "sector_count": [int(len(selected))],
                "sector_ids": [",".join(selected[sector_id].astype(str).sort_values().tolist())],
            },
            geometry=[zbe_geometry],
            crs=WORK_CRS,
        ).to_crs("EPSG:4326")

        meta = {
            "selection_mode": "official_sector_ids",
            "requested_sector_count": int(len(requested_ids)),
            "selected_sector_count": int(len(selected)),
            "selected_sector_ids": selected[sector_id].astype(str).sort_values().tolist(),
            "missing_sector_ids": missing_ids,
            "zbe_polygon_buffer_m": 0.0,
        }
        return zbe_frame, meta

    traffic_sensors = (
        traffic_daily[["entity_id", "lat", "lon"]]
        .dropna(subset=["lat", "lon"])
        .drop_duplicates("entity_id")
        .reset_index(drop=True)
    )
    if traffic_sensors.empty:
        raise ValueError("No hay sensores de trafico disponibles para definir la ZBE funcional.")

    traffic_sensors["entity_id"] = traffic_sensors["entity_id"].astype(str)
    preferred_ids = {str(sensor_id) for sensor_id in qc_layer.ZBE_TRAFFIC_SENSOR_IDS}
    selected = traffic_sensors.loc[traffic_sensors["entity_id"].isin(preferred_ids)].copy()
    selection_mode = "qc_layer.ZBE_TRAFFIC_SENSOR_IDS"

    if len(selected) < 3:
        selected = traffic_sensors.copy()
        selection_mode = "all_available_traffic_sensors"

    sensor_points = gpd.GeoDataFrame(
        selected.copy(),
        geometry=gpd.points_from_xy(selected["lon"], selected["lat"]),
        crs="EPSG:4326",
    ).to_crs(WORK_CRS)

    base_geometry = sensor_points.geometry.union_all().convex_hull
    effective_buffer_m = float(zbe_polygon_buffer_m)
    if base_geometry.geom_type not in {"Polygon", "MultiPolygon"} and effective_buffer_m <= 0:
        effective_buffer_m = 25.0
    zbe_geometry = base_geometry.buffer(effective_buffer_m) if effective_buffer_m > 0 else base_geometry

    zbe_frame = gpd.GeoDataFrame(
        {
            "kind": ["zbe_funcional"],
            "selection_mode": [selection_mode],
            "sensor_count": [int(len(selected))],
            "sensor_ids": [",".join(selected["entity_id"].sort_values().tolist())],
        },
        geometry=[zbe_geometry],
        crs=WORK_CRS,
    ).to_crs("EPSG:4326")

    meta = {
        "selection_mode": selection_mode,
        "requested_sensor_count": int(len(preferred_ids)),
        "available_sensor_count": int(len(traffic_sensors)),
        "selected_sensor_count": int(len(selected)),
        "selected_sensor_ids": selected["entity_id"].sort_values().tolist(),
        "zbe_polygon_buffer_m": float(effective_buffer_m),
    }
    return zbe_frame, meta


def classify_sector_zones(
    sectors: gpd.GeoDataFrame,
    zbe_geometry: gpd.GeoDataFrame,
    exit_border_buffer_m: float,
    exit_outer_buffer_m: float,
) -> tuple[gpd.GeoDataFrame, dict[str, object]]:
    sectors_proj = sectors.to_crs(WORK_CRS).copy()
    zbe_proj = zbe_geometry.to_crs(WORK_CRS)
    zbe_polygon = zbe_proj.geometry.iloc[0]

    centroids = sectors_proj.geometry.centroid
    distance_to_zbe_m = centroids.distance(zbe_polygon)
    interior_mask = distance_to_zbe_m <= 0.0
    border_mask = (~interior_mask) & (distance_to_zbe_m <= float(exit_border_buffer_m))
    exterior_mask = (~interior_mask) & (~border_mask) & (distance_to_zbe_m <= float(exit_outer_buffer_m))

    sectors_proj["sector_zone"] = SECTOR_ZONE_OUTSIDE
    sectors_proj.loc[interior_mask, "sector_zone"] = SECTOR_ZONE_INTERIOR
    sectors_proj.loc[border_mask, "sector_zone"] = SECTOR_ZONE_BORDER
    sectors_proj.loc[exterior_mask, "sector_zone"] = SECTOR_ZONE_EXTERIOR
    sectors_proj["distance_to_zbe_km"] = distance_to_zbe_m / 1000.0
    sectors_proj["is_zbe_interior"] = interior_mask.astype(bool)
    sectors_proj["is_exit_border"] = border_mask.astype(bool)
    sectors_proj["is_exit_exterior"] = exterior_mask.astype(bool)
    sectors_proj["is_exit_inner_border"] = False

    interior_indices = sectors_proj.index[interior_mask].tolist()
    non_interior = sectors_proj.loc[~interior_mask, ["geometry"]].copy()
    if interior_indices and not non_interior.empty:
        non_interior_sindex = non_interior.sindex
        for index in interior_indices:
            geometry = sectors_proj.at[index, "geometry"]
            candidate_idx = list(non_interior_sindex.intersection(geometry.bounds))
            if not candidate_idx:
                continue
            candidates = non_interior.iloc[candidate_idx]
            touches_non_interior = candidates.geometry.touches(geometry).any()
            intersects_non_interior = candidates.geometry.intersects(geometry.boundary).any()
            if touches_non_interior or intersects_non_interior:
                sectors_proj.at[index, "is_exit_inner_border"] = True

    counts = sectors_proj["sector_zone"].value_counts().to_dict()
    meta = {
        "interior_sector_count": int(counts.get(SECTOR_ZONE_INTERIOR, 0)),
        "inner_border_sector_count": int(sectors_proj["is_exit_inner_border"].sum()),
        "border_sector_count": int(counts.get(SECTOR_ZONE_BORDER, 0)),
        "exterior_sector_count": int(counts.get(SECTOR_ZONE_EXTERIOR, 0)),
        "outside_model_sector_count": int(counts.get(SECTOR_ZONE_OUTSIDE, 0)),
        "exit_border_buffer_m": float(exit_border_buffer_m),
        "exit_outer_buffer_m": float(exit_outer_buffer_m),
    }
    return sectors_proj.to_crs("EPSG:4326").reset_index(drop=True), meta


def build_daily_sector_surface(
    traffic_daily: pd.DataFrame,
    sectors: gpd.GeoDataFrame,
    sector_id: str,
    centroid_xy: np.ndarray,
    influence_radius_km: float,
    min_local_stations: int,
    idw_power: float,
) -> tuple[dict[pd.Timestamp, np.ndarray], pd.DataFrame]:
    sector_ids = sectors[sector_id].tolist()
    sector_zones = sectors["sector_zone"].astype(str).tolist()
    surfaces: dict[pd.Timestamp, np.ndarray] = {}
    records: list[dict[str, object]] = []

    for local_day, day_frame in traffic_daily.groupby("local_day", sort=True):
        points_xy = spatial_layer.project_points_xy(day_frame)
        surface = spatial_layer.inverse_distance_interpolation(
            centroid_xy=centroid_xy,
            point_xy=points_xy,
            values=day_frame["value"].to_numpy(dtype=float),
            influence_radius_km=influence_radius_km,
            min_local_stations=min_local_stations,
            idw_power=idw_power,
        )
        surfaces[pd.Timestamp(local_day)] = surface

        for index, sector_value in enumerate(surface):
            records.append(
                {
                    "local_day": local_day,
                    sector_id: sector_ids[index],
                    "sector_zone": sector_zones[index],
                    "traffic_support": sector_value,
                }
            )

    return surfaces, pd.DataFrame(records)


def normalize_positive_weights(surface: np.ndarray, mask: np.ndarray) -> np.ndarray:
    allowed = np.asarray(mask, dtype=bool)
    weights = np.zeros(len(surface), dtype=float)
    if not allowed.any():
        return weights

    candidate = np.where(
        allowed,
        np.nan_to_num(np.asarray(surface, dtype=float), nan=0.0, posinf=0.0, neginf=0.0),
        0.0,
    )
    candidate = np.clip(candidate, 0.0, None)
    total = float(candidate.sum())
    if total > 0:
        return candidate / total

    weights[allowed] = 1.0 / float(allowed.sum())
    return weights


def extract_positive_support(surface: np.ndarray, mask: np.ndarray) -> np.ndarray:
    allowed = np.asarray(mask, dtype=bool)
    if not allowed.any():
        return np.zeros(len(surface), dtype=float)

    candidate = np.where(
        allowed,
        np.nan_to_num(np.asarray(surface, dtype=float), nan=0.0, posinf=0.0, neginf=0.0),
        0.0,
    )
    return np.clip(candidate, 0.0, None)


def blend_exit_weights(
    surface: np.ndarray,
    border_mask: np.ndarray,
    exterior_mask: np.ndarray,
    border_share: float,
    exterior_share: float,
) -> np.ndarray:
    result = np.zeros(len(surface), dtype=float)
    available: list[tuple[str, float]] = []

    if np.asarray(border_mask, dtype=bool).any():
        available.append(("border", max(float(border_share), 0.0)))
    if np.asarray(exterior_mask, dtype=bool).any():
        available.append(("exterior", max(float(exterior_share), 0.0)))
    if not available:
        return result

    total_share = float(sum(share for _, share in available))
    if total_share <= 0:
        normalized_share = {name: 1.0 / len(available) for name, _ in available}
    else:
        normalized_share = {name: share / total_share for name, share in available}

    if np.asarray(border_mask, dtype=bool).any():
        result += normalized_share.get("border", 0.0) * normalize_positive_weights(surface, border_mask)
    if np.asarray(exterior_mask, dtype=bool).any():
        result += normalized_share.get("exterior", 0.0) * normalize_positive_weights(surface, exterior_mask)
    return result


def blend_exit_support(
    surface: np.ndarray,
    border_mask: np.ndarray,
    exterior_mask: np.ndarray,
    border_share: float,
    exterior_share: float,
) -> np.ndarray:
    result = np.zeros(len(surface), dtype=float)
    available: list[tuple[str, float]] = []

    if np.asarray(border_mask, dtype=bool).any():
        available.append(("border", max(float(border_share), 0.0)))
    if np.asarray(exterior_mask, dtype=bool).any():
        available.append(("exterior", max(float(exterior_share), 0.0)))
    if not available:
        return result

    total_share = float(sum(share for _, share in available))
    if total_share <= 0:
        normalized_share = {name: 1.0 / len(available) for name, _ in available}
    else:
        normalized_share = {name: share / total_share for name, share in available}

    if np.asarray(border_mask, dtype=bool).any():
        result += normalized_share.get("border", 0.0) * extract_positive_support(surface, border_mask)
    if np.asarray(exterior_mask, dtype=bool).any():
        result += normalized_share.get("exterior", 0.0) * extract_positive_support(surface, exterior_mask)
    return result


def build_daily_proxy_components(
    sectors: gpd.GeoDataFrame,
    sector_id: str,
    inventory_daily: pd.DataFrame,
    daily_surfaces: dict[pd.Timestamp, np.ndarray],
    daily_hours: float,
    exit_border_share: float,
    exit_exterior_share: float,
) -> pd.DataFrame:
    masks = {
        "all": np.ones(len(sectors), dtype=bool),
        "interior": sectors["sector_zone"].astype(str).eq(SECTOR_ZONE_INTERIOR).to_numpy(dtype=bool),
        "inner_border": sectors["is_exit_inner_border"].fillna(False).to_numpy(dtype=bool),
        "border": sectors["sector_zone"].astype(str).eq(SECTOR_ZONE_BORDER).to_numpy(dtype=bool),
        "exterior": sectors["sector_zone"].astype(str).eq(SECTOR_ZONE_EXTERIOR).to_numpy(dtype=bool),
    }
    exit_mask = masks["inner_border"] | masks["border"] | masks["exterior"]
    sector_ids = sectors[sector_id].tolist()
    sector_zones = sectors["sector_zone"].astype(str).tolist()
    inventory_indexed = inventory_daily.set_index("local_day")
    records: list[dict[str, object]] = []

    for local_day in sorted(daily_surfaces):
        if local_day not in inventory_indexed.index:
            continue

        day_surface = daily_surfaces[local_day]
        day_row = inventory_indexed.loc[local_day]
        if isinstance(day_row, pd.DataFrame):
            day_row = day_row.iloc[0]

        counted_support = extract_positive_support(day_surface, masks["all"])
        interior_support = extract_positive_support(day_surface, masks["interior"])
        exit_support = blend_exit_support(
            surface=day_surface,
            border_mask=masks["inner_border"] | masks["border"],
            exterior_mask=masks["exterior"],
            border_share=exit_border_share,
            exterior_share=exit_exterior_share,
        )

        counted_weights = normalize_positive_weights(day_surface, masks["all"])
        interior_weights = normalize_positive_weights(day_surface, masks["interior"])
        border_family_weights = normalize_positive_weights(day_surface, masks["inner_border"] | masks["border"])
        exterior_family_weights = normalize_positive_weights(day_surface, masks["exterior"])
        exit_weights = np.zeros(len(day_surface), dtype=float)
        available_exit_families: list[tuple[str, float]] = []
        if np.any((masks["inner_border"] | masks["border"])):
            available_exit_families.append(("border_family", max(float(exit_border_share), 0.0)))
        if np.any(masks["exterior"]):
            available_exit_families.append(("exterior", max(float(exit_exterior_share), 0.0)))
        if available_exit_families:
            total_family_share = float(sum(share for _, share in available_exit_families))
            if total_family_share <= 0:
                normalized_family_share = {name: 1.0 / len(available_exit_families) for name, _ in available_exit_families}
            else:
                normalized_family_share = {
                    name: share / total_family_share for name, share in available_exit_families
                }
            exit_weights += normalized_family_share.get("border_family", 0.0) * border_family_weights
            exit_weights += normalized_family_share.get("exterior", 0.0) * exterior_family_weights

        nox_counted = (float(day_row["factor_nox_g_por_viaje_counted"]) / daily_hours) * counted_support
        nox_interior_raw = (float(day_row["factor_nox_g_por_viaje_interior"]) / daily_hours) * interior_support
        nox_salidas_raw = (float(day_row["factor_nox_g_por_viaje_salidas"]) / daily_hours) * exit_support
        co2_counted = (float(day_row["factor_co2_g_por_viaje_counted"]) / daily_hours) * counted_support
        co2_interior_raw = (float(day_row["factor_co2_g_por_viaje_interior"]) / daily_hours) * interior_support
        co2_salidas_raw = (float(day_row["factor_co2_g_por_viaje_salidas"]) / daily_hours) * exit_support

        nox_interior = np.where(masks["interior"], nox_interior_raw, np.nan)
        nox_salidas = np.where(exit_mask, nox_salidas_raw, np.nan)
        co2_interior = np.where(masks["interior"], co2_interior_raw, np.nan)
        co2_salidas = np.where(exit_mask, co2_salidas_raw, np.nan)

        nox_total = nox_counted + np.nan_to_num(nox_interior, nan=0.0) + np.nan_to_num(nox_salidas, nan=0.0)
        co2_total = co2_counted + np.nan_to_num(co2_interior, nan=0.0) + np.nan_to_num(co2_salidas, nan=0.0)

        for index, sector_value in enumerate(day_surface):
            records.append(
                {
                    "local_day": local_day,
                    sector_id: sector_ids[index],
                    "sector_zone": sector_zones[index],
                    "traffic_support": sector_value,
                    "support_counted": counted_support[index],
                    "support_interior": interior_support[index],
                    "support_salidas": exit_support[index],
                    "weight_counted": counted_weights[index],
                    "weight_interior": interior_weights[index],
                    "weight_salidas": exit_weights[index],
                    "nox_proxy_counted": nox_counted[index],
                    "nox_proxy_interior": nox_interior[index],
                    "nox_proxy_salidas": nox_salidas[index],
                    "nox_proxy_total": nox_total[index],
                    "co2_proxy_counted": co2_counted[index],
                    "co2_proxy_interior": co2_interior[index],
                    "co2_proxy_salidas": co2_salidas[index],
                    "co2_proxy_total": co2_total[index],
                }
            )

    return pd.DataFrame(records)


def build_sector_proxy_means(
    sectors: gpd.GeoDataFrame,
    daily_proxy_components: pd.DataFrame,
    sector_id: str,
) -> gpd.GeoDataFrame:
    if daily_proxy_components.empty:
        raise ValueError("No se han podido construir componentes diarios de proxy por sector.")

    numeric_columns = [
        "traffic_support",
        "support_counted",
        "support_interior",
        "support_salidas",
        "weight_counted",
        "weight_interior",
        "weight_salidas",
        *DEFAULT_MAP_VARIABLES,
    ]
    mean_values = (
        daily_proxy_components.groupby(sector_id, as_index=False)[numeric_columns]
        .mean()
        .rename(columns={"traffic_support": "traffic_support_mean"})
    )
    return sectors.merge(mean_values, on=sector_id, how="left")


def build_pairs(nox_targets: list[str], co2_targets: list[str]) -> list[tuple[str, str]]:
    pairs: list[tuple[str, str]] = []
    nox_targets_unique = spatial_layer.unique_preserve_order(nox_targets)
    co2_targets_unique = spatial_layer.unique_preserve_order(co2_targets)

    for source in ["nox_proxy_counted", "nox_proxy_total"]:
        pairs.extend((source, target) for target in nox_targets_unique)
    for source in ["co2_proxy_counted", "co2_proxy_total"]:
        pairs.extend((source, target) for target in co2_targets_unique)
    return pairs


def build_summary(
    args: argparse.Namespace,
    overlap_day_index: pd.DatetimeIndex,
    inventory_daily: pd.DataFrame,
    pairs: list[tuple[str, str]],
    sector_selection: dict[str, object],
    traffic_selection: dict[str, object],
    valid_sector_count_by_variable: dict[str, int],
    zbe_meta: dict[str, object],
    sector_zone_meta: dict[str, object],
) -> dict[str, object]:
    output_dir = args.output_dir
    return {
        "article": {
            "journal": "Experimental",
            "year": 2026,
            "volume": None,
            "article_number": None,
            "title": "LISA bivariante con proxies sectoriales de trayectos counted, interiores y salidas",
        },
        "methodology": [
            "Daily split of inventory trips into counted, interior-only and exits",
            "Daily inventory emissions allocated to those three trip groups using trip counts",
            "Daily traffic support interpolated to census-sector centroids from entry traffic sensors",
            "Daily g/trip factors estimated from the connected-vehicle inventory for counted, interior and exit groups",
            "Counted emissions estimated as g/trip times raw traffic support across all study sectors",
            "Interior-only emissions estimated as g/trip times raw traffic support inside interior ZBE sectors",
            "Exit emissions estimated as g/trip times raw traffic support across inner-border, border and exterior sectors using configurable shares",
            "Daily pollutant means by air-quality station",
            "Inverse-distance interpolation to sector centroids",
            "Mean value by sector across the overlapping study period",
            "Queen contiguity weights between sectors",
            "Global Moran's I, Local Moran's I, Getis-Ord Gi* and bivariate Moran/LISA",
        ],
        "weight_note": (
            "The trip-weighted proxy no longer conserves the daily inventory mass by normalization. Instead, each "
            "component applies its daily g/trip factor to the raw sector traffic support, masking interior and "
            "exit components to the sectors where each trip type is assumed to occur."
        ),
        "inputs": {
            "sensor_csv": str(args.sensor_csv),
            "inventory_csv": str(args.inventory_csv),
            "sectors": str(args.sectors),
            "value_column": args.value_column,
            "sector_id": args.sector_id,
            "traffic_param": args.traffic_param,
            "zbe_source": args.zbe_source,
            "sensor_variables": spatial_layer.unique_preserve_order(args.sensor_variables),
            "proxy_variables": DEFAULT_MAP_VARIABLES,
            "univariate_variables": DEFAULT_MAP_VARIABLES,
            "nox_targets": spatial_layer.unique_preserve_order(args.nox_targets),
            "co2_targets": spatial_layer.unique_preserve_order(args.co2_targets),
            "bivariate_pairs": [{"variable_x": x, "variable_y": y} for x, y in pairs],
        },
        "study_period_local": {
            "start_day": str(pd.Timestamp(overlap_day_index.min()).date()),
            "end_day": str(pd.Timestamp(overlap_day_index.max()).date()),
        },
        "inventory_daily_group_summary": {
            "days": int(len(inventory_daily)),
            "mean_trips_counted": float(inventory_daily["trips_counted"].mean()),
            "mean_trips_interior": float(inventory_daily["trips_interior"].mean()),
            "mean_trips_salidas": float(inventory_daily["trips_salidas"].mean()),
            "mean_share_counted": float(inventory_daily["share_counted"].mean()),
            "mean_share_interior": float(inventory_daily["share_interior"].mean()),
            "mean_share_salidas": float(inventory_daily["share_salidas"].mean()),
            "mean_nox_counted_g": float(inventory_daily["emisiones_nox_counted_g"].mean()),
            "mean_nox_interior_g": float(inventory_daily["emisiones_nox_interior_g"].mean()),
            "mean_nox_salidas_g": float(inventory_daily["emisiones_nox_salidas_g"].mean()),
            "mean_co2_counted_g": float(inventory_daily["emisiones_co2_counted_g"].mean()),
            "mean_co2_interior_g": float(inventory_daily["emisiones_co2_interior_g"].mean()),
            "mean_co2_salidas_g": float(inventory_daily["emisiones_co2_salidas_g"].mean()),
        },
        "functional_zbe": zbe_meta,
        "sector_zones": sector_zone_meta,
        "sector_selection": sector_selection,
        "sector_value_filter": {
            "influence_radius_km": float(args.sector_influence_radius_km),
            "min_local_stations": int(args.sector_min_local_stations),
            "valid_sector_count_by_variable": valid_sector_count_by_variable,
        },
        "traffic_selection": traffic_selection,
        "sector_count": int(sector_selection["sector_count"]),
        "outputs": {
            "inventory_daily_split_csv": str(output_dir / "inventory_daily_split.csv"),
            "daily_sector_support_csv": str(output_dir / "daily_sector_support.csv"),
            "daily_sector_proxy_components_csv": str(output_dir / "daily_sector_proxy_components.csv"),
            "zbe_geometry_geojson": str(output_dir / "zbe_functional_geometry.geojson"),
            "sector_results_geojson": str(output_dir / "sector_results.geojson"),
            "univariate_global_csv": str(output_dir / "univariate_global_results.csv"),
            "bivariate_global_csv": str(output_dir / "bivariate_global_results.csv"),
            "summary_json": str(output_dir / "run_summary.json"),
        },
    }


def write_json(path: Path, payload: dict[str, object]) -> None:
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")


def main() -> None:
    args = parse_args()
    spatial_layer.ensure_output_dir(args.output_dir)

    if args.daily_hours <= 0:
        raise ValueError("--daily-hours must be > 0")
    if args.zbe_polygon_buffer_m < 0:
        raise ValueError("--zbe-polygon-buffer-m must be >= 0")
    if args.exit_border_buffer_m < 0:
        raise ValueError("--exit-border-buffer-m must be >= 0")
    if args.exit_outer_buffer_m < args.exit_border_buffer_m:
        raise ValueError("--exit-outer-buffer-m must be >= --exit-border-buffer-m")
    if args.exit_border_share < 0 or args.exit_exterior_share < 0:
        raise ValueError("Exit shares must be >= 0")
    if args.sector_influence_radius_km <= 0:
        raise ValueError("--sector-influence-radius-km must be > 0")
    if args.sector_min_local_stations < 1:
        raise ValueError("--sector-min-local-stations must be >= 1")
    if args.sector_idw_power <= 0:
        raise ValueError("--sector-idw-power must be > 0")

    requested_start = spatial_layer.parse_local_date(args.start_date, args.timezone, is_end=False)
    requested_end = spatial_layer.parse_local_date(args.end_date, args.timezone, is_end=True)
    sensor_variables = spatial_layer.unique_preserve_order(args.sensor_variables)
    value_column = spatial_layer.resolve_value_column(args.sensor_csv, args.value_column)
    args.value_column = value_column

    inventory_daily = load_inventory_daily_split(
        path=args.inventory_csv,
        timezone=args.timezone,
        start_date=requested_start,
        end_date=requested_end,
    )
    sensor_daily_initial, _ = spatial_layer.load_daily_values(
        path=args.sensor_csv,
        variables=sensor_variables,
        value_column=value_column,
        timezone=args.timezone,
        start_date=requested_start,
        end_date=requested_end,
        selected_sectors=None,
    )
    traffic_daily_initial, _ = spatial_layer.load_daily_values(
        path=args.sensor_csv,
        variables=[args.traffic_param],
        value_column=value_column,
        timezone=args.timezone,
        start_date=requested_start,
        end_date=requested_end,
        selected_sectors=None,
    )

    overlap_day_index = overlap_days(sensor_daily_initial, inventory_daily)
    traffic_day_index = pd.DatetimeIndex(traffic_daily_initial["local_day"].drop_duplicates().sort_values())
    overlap_day_index = overlap_day_index.intersection(traffic_day_index).sort_values()
    if overlap_day_index.empty:
        raise ValueError("No overlapping local days were found across inventory, pollutants and traffic.")

    inventory_daily = inventory_daily.loc[inventory_daily["local_day"].isin(overlap_day_index)].copy()
    overlap_start, overlap_end = bounds_from_days(overlap_day_index)

    sectors = spatial_layer.load_sectors(args.sectors, args.sector_id)
    air_sensors = spatial_layer.load_air_quality_sensors(
        path=args.sensor_csv,
        timezone=args.timezone,
        start_date=overlap_start,
        end_date=overlap_end,
    )
    sectors, sector_selection = spatial_layer.select_study_sectors(
        sectors=sectors,
        air_sensors=air_sensors,
        core_radius_km=args.sector_core_radius_km,
        study_buffer_m=args.sector_study_buffer_m,
        max_nearest_sensor_km=args.sector_max_nearest_sensor_km,
    )

    pollutant_daily, _ = spatial_layer.load_daily_values(
        path=args.sensor_csv,
        variables=sensor_variables,
        value_column=value_column,
        timezone=args.timezone,
        start_date=overlap_start,
        end_date=overlap_end,
        selected_sectors=sectors,
    )
    traffic_daily, traffic_selection = spatial_layer.load_daily_values(
        path=args.sensor_csv,
        variables=[args.traffic_param],
        value_column=value_column,
        timezone=args.timezone,
        start_date=overlap_start,
        end_date=overlap_end,
        selected_sectors=sectors,
    )

    zbe_traffic_daily = traffic_daily_initial.loc[
        traffic_daily_initial["local_day"].isin(overlap_day_index)
    ].copy()
    zbe_geometry, zbe_meta = build_zbe_geometry(
        sectors=sectors,
        sector_id=args.sector_id,
        traffic_daily=zbe_traffic_daily if not zbe_traffic_daily.empty else traffic_daily,
        zbe_source=args.zbe_source,
        zbe_polygon_buffer_m=args.zbe_polygon_buffer_m,
    )
    sectors, sector_zone_meta = classify_sector_zones(
        sectors=sectors,
        zbe_geometry=zbe_geometry,
        exit_border_buffer_m=args.exit_border_buffer_m,
        exit_outer_buffer_m=args.exit_outer_buffer_m,
    )
    if sector_zone_meta["interior_sector_count"] <= 0:
        raise ValueError("No hay sectores interiores ZBE con la geometria funcional actual.")
    if (
        sector_zone_meta["border_sector_count"] + sector_zone_meta["exterior_sector_count"]
    ) <= 0:
        raise ValueError("No hay sectores de borde o exterior para repartir las salidas.")

    centroid_xy = spatial_layer.build_centroid_xy(sectors)
    daily_surfaces, daily_support_frame = build_daily_sector_surface(
        traffic_daily=traffic_daily,
        sectors=sectors,
        sector_id=args.sector_id,
        centroid_xy=centroid_xy,
        influence_radius_km=args.sector_influence_radius_km,
        min_local_stations=args.sector_min_local_stations,
        idw_power=args.sector_idw_power,
    )

    support_day_index = pd.DatetimeIndex(sorted(daily_surfaces)).sort_values()
    overlap_day_index = overlap_day_index.intersection(support_day_index).sort_values()
    if overlap_day_index.empty:
        raise ValueError("No overlapping days remain after building the sector traffic support.")

    inventory_daily = inventory_daily.loc[inventory_daily["local_day"].isin(overlap_day_index)].copy()
    pollutant_daily = pollutant_daily.loc[pollutant_daily["local_day"].isin(overlap_day_index)].copy()
    daily_support_frame = daily_support_frame.loc[daily_support_frame["local_day"].isin(overlap_day_index)].copy()
    daily_surfaces = {day: daily_surfaces[day] for day in overlap_day_index if day in daily_surfaces}

    daily_proxy_components = build_daily_proxy_components(
        sectors=sectors,
        sector_id=args.sector_id,
        inventory_daily=inventory_daily,
        daily_surfaces=daily_surfaces,
        daily_hours=float(args.daily_hours),
        exit_border_share=float(args.exit_border_share),
        exit_exterior_share=float(args.exit_exterior_share),
    )
    sector_with_proxies = build_sector_proxy_means(
        sectors=sectors,
        daily_proxy_components=daily_proxy_components,
        sector_id=args.sector_id,
    )

    sector_values, _, pollutant_valid_counts = spatial_layer.interpolate_sector_means(
        sectors=sector_with_proxies,
        centroid_xy=centroid_xy,
        daily_values=pollutant_daily,
        variables=sensor_variables,
        influence_radius_km=args.sector_influence_radius_km,
        min_local_stations=args.sector_min_local_stations,
        idw_power=args.sector_idw_power,
    )

    proxy_valid_counts = {
        variable: int(sector_values[variable].notna().sum())
        for variable in DEFAULT_MAP_VARIABLES
        if variable in sector_values.columns
    }
    valid_sector_count_by_variable = {**pollutant_valid_counts, **proxy_valid_counts}

    loaded_variables = spatial_layer.unique_preserve_order(sensor_variables + DEFAULT_MAP_VARIABLES)
    pairs = build_pairs(args.nox_targets, args.co2_targets)
    sector_values, univariate_global = spatial_layer.compute_univariate_results(
        sectors=sector_values,
        variables=loaded_variables,
        sector_id=args.sector_id,
        permutations=args.permutations,
        p_threshold=args.p_threshold,
    )
    sector_values, bivariate_global = spatial_layer.compute_bivariate_results(
        sectors=sector_values,
        variable_pairs=pairs,
        sector_id=args.sector_id,
        permutations=args.permutations,
        p_threshold=args.p_threshold,
    )

    inventory_split_path = args.output_dir / "inventory_daily_split.csv"
    support_path = args.output_dir / "daily_sector_support.csv"
    components_path = args.output_dir / "daily_sector_proxy_components.csv"
    zbe_geometry_path = args.output_dir / "zbe_functional_geometry.geojson"
    sector_results_path = args.output_dir / "sector_results.geojson"
    univariate_path = args.output_dir / "univariate_global_results.csv"
    bivariate_path = args.output_dir / "bivariate_global_results.csv"
    summary_path = args.output_dir / "run_summary.json"

    inventory_daily.to_csv(inventory_split_path, index=False)
    daily_support_frame.to_csv(support_path, index=False)
    daily_proxy_components.to_csv(components_path, index=False)
    zbe_geometry.to_file(zbe_geometry_path, driver="GeoJSON")
    sector_values.to_file(sector_results_path, driver="GeoJSON")
    univariate_global.to_csv(univariate_path, index=False)
    bivariate_global.to_csv(bivariate_path, index=False)

    summary = build_summary(
        args=args,
        overlap_day_index=overlap_day_index,
        inventory_daily=inventory_daily,
        pairs=pairs,
        sector_selection=sector_selection,
        traffic_selection=traffic_selection,
        valid_sector_count_by_variable=valid_sector_count_by_variable,
        zbe_meta=zbe_meta,
        sector_zone_meta=sector_zone_meta,
    )
    write_json(summary_path, summary)

    print(f"Inventory daily split: {inventory_split_path}")
    print(f"Daily sector support: {support_path}")
    print(f"Daily sector proxy components: {components_path}")
    print(f"Functional ZBE geometry: {zbe_geometry_path}")
    print(f"Sector results: {sector_results_path}")
    print(f"Univariate global results: {univariate_path}")
    print(f"Bivariate global results: {bivariate_path}")
    print(f"Summary: {summary_path}")


if __name__ == "__main__":
    main()
