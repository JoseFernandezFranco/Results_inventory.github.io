from __future__ import annotations

import argparse
import sys
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parent
PIPELINE_ROOT = PROJECT_ROOT / ".runtime" / "Definitivo_Limpio"
if str(PIPELINE_ROOT) not in sys.path:
    sys.path.insert(0, str(PIPELINE_ROOT))

from pipeline import render_layer


STUDY_ROOT = PROJECT_ROOT
DEFAULT_RESULTS_DIR = STUDY_ROOT / "results" / "inventario_trip_proxy_lisa"
MAP_VARIABLES = [
    "nox_proxy_counted",
    "nox_proxy_interior",
    "nox_proxy_salidas",
    "nox_proxy_total",
    "co2_proxy_counted",
    "co2_proxy_interior",
    "co2_proxy_salidas",
    "co2_proxy_total",
]
PROXY_LABELS = {
    "nox_proxy_counted": "NOx counted",
    "nox_proxy_interior": "NOx interiores ZBE",
    "nox_proxy_salidas": "NOx salidas",
    "nox_proxy_total": "NOx total espacializado",
    "co2_proxy_counted": "CO2 counted",
    "co2_proxy_interior": "CO2 interiores ZBE",
    "co2_proxy_salidas": "CO2 salidas",
    "co2_proxy_total": "CO2 total espacializado",
}
PROXY_NOTES = {
    "nox_proxy_counted": [
        "Valor medio sectorial del componente contado por los sensores de entrada.",
        "La masa diaria de NOx counted se reparte segun el soporte espacial derivado del trafico medido.",
    ],
    "nox_proxy_interior": [
        "Valor medio sectorial del componente de trayectos que se mantienen dentro.",
        "Solo se representa en sectores interiores a la ZBE oficial aproximada; fuera de ellos aparece sin dato.",
    ],
    "nox_proxy_salidas": [
        "Valor medio sectorial del componente de trayectos que salen desde la ZBE.",
        "Se representa en sectores de borde interior, borde y exterior, con pesos configurables entre las familias de salida.",
    ],
    "nox_proxy_total": [
        "Suma de los componentes counted, interiores y salidas tras espacializar cada tipo de viaje con su propia logica.",
        "Es la capa recomendada para contrastar la huella total del inventario frente a contaminantes medidos.",
    ],
    "co2_proxy_counted": [
        "Valor medio sectorial del componente counted de CO2.",
        "La estructura espacial procede del trafico observado en sensores de entrada.",
    ],
    "co2_proxy_interior": [
        "Valor medio sectorial del componente interior de CO2.",
        "Se limita a sectores interiores de la ZBE oficial aproximada para mantener coherencia con el tipo de trayecto.",
    ],
    "co2_proxy_salidas": [
        "Valor medio sectorial del componente salidas de CO2.",
        "Se limita a sectores de borde interior, borde y exterior segun los pesos de reparto definidos en el build.",
    ],
    "co2_proxy_total": [
        "Suma espacializada de CO2 counted, interior y salidas.",
        "Permite comparar el patron total del inventario con el CO2 ambiente usando una geometria coherente por viaje.",
    ],
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Genera mapas HTML interactivos a partir de los resultados creados por "
            "build_inventory_trip_proxy_lisa.py."
        )
    )
    parser.add_argument(
        "--results-dir",
        type=Path,
        default=DEFAULT_RESULTS_DIR,
        help="Carpeta con sector_results.geojson, run_summary.json y los CSV globales.",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=None,
        help="Carpeta de salida para los HTML. Por defecto usa <results-dir>/maps.",
    )
    return parser.parse_args()


def apply_proxy_labels() -> None:
    original_value_scale_label = render_layer.value_scale_label
    original_value_scale_notes = render_layer.value_scale_notes

    def custom_label(column: str) -> str:
        return PROXY_LABELS.get(column, original_value_scale_label(column))

    def custom_notes(column: str, values=None) -> list[str]:
        if column in PROXY_NOTES:
            return PROXY_NOTES[column]
        return original_value_scale_notes(column, values)

    render_layer.value_scale_label = custom_label
    render_layer.value_scale_notes = custom_notes


def main() -> None:
    args = parse_args()
    output_dir = args.output_dir or (args.results_dir / "maps")
    render_layer.ensure_dir(output_dir)

    apply_proxy_labels()
    sectors, summary, univariate, bivariate = render_layer.load_inputs(args.results_dir)
    inputs = summary.setdefault("inputs", {})
    inputs["univariate_variables"] = MAP_VARIABLES
    render_layer.build_map_set(
        sectors=sectors,
        summary=summary,
        univariate=univariate,
        bivariate=bivariate,
        output_dir=output_dir,
    )
    print(f"Mapas HTML guardados en: {output_dir}")


if __name__ == "__main__":
    main()
