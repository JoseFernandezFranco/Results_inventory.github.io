from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import pandas as pd


PROJECT_ROOT = Path(__file__).resolve().parent
PIPELINE_ROOT = PROJECT_ROOT / ".runtime" / "Definitivo_Limpio"
if str(PIPELINE_ROOT) not in sys.path:
    sys.path.insert(0, str(PIPELINE_ROOT))

from pipeline import spatial_layer


STUDY_ROOT = PROJECT_ROOT
DEFAULT_SENSOR_CSV = STUDY_ROOT / "combined_flags.csv"
DEFAULT_INVENTORY_CSV = STUDY_ROOT / "inventario_cartagena_maestro.csv"
DEFAULT_SECTORS = PIPELINE_ROOT / "data_static" / "cartagena_census_sections.geojson"
DEFAULT_OUTPUT_DIR = STUDY_ROOT / "results" / "inventario_traffic_proxy_lisa"
DEFAULT_SENSOR_VARIABLES = ["CO", "NO2", "O3", "SO2", "PM10", "PM25", "PM1", "VOC", "CO2"]
DEFAULT_TRAFFIC_PARAM = "coches_total"
DEFAULT_NOX_TARGETS = ["NO2", "PM10", "PM25", "VOC"]
DEFAULT_CO2_TARGETS = ["CO2"]
PROXY_PARAM_FACTORS = {
    "nox_proxy_trafico": "factor_nox_g_por_viaje",
    "co2_proxy_trafico": "factor_co2_g_por_viaje",
}
TRIP_COLUMNS = [
    "trayectos_inician_y_finalizan",
    "trayectos_inician",
    "trayectos_finalizan",
    "trayectos_cruzan",
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Construye proxies de emision a partir del inventario diario y del trafico "
            "observado, y ejecuta un LISA bivariante sobre sectores."
        )
    )
    parser.add_argument("--sensor-csv", type=Path, default=DEFAULT_SENSOR_CSV, help="CSV QC compacto con sensores.")
    parser.add_argument(
        "--inventory-csv",
        type=Path,
        default=DEFAULT_INVENTORY_CSV,
        help="CSV maestro del inventario de vehiculos conectados.",
    )
    parser.add_argument(
        "--sectors",
        type=Path,
        default=DEFAULT_SECTORS,
        help="GeoJSON de secciones censales usado por el estudio.",
    )
    parser.add_argument(
        "--sensor-variables",
        nargs="+",
        default=DEFAULT_SENSOR_VARIABLES,
        help="Contaminantes de sensores que entran al estudio sectorial.",
    )
    parser.add_argument(
        "--traffic-param",
        default=DEFAULT_TRAFFIC_PARAM,
        help="Parametro de trafico usado para espacializar los factores del inventario.",
    )
    parser.add_argument(
        "--nox-targets",
        nargs="+",
        default=DEFAULT_NOX_TARGETS,
        help="Variables objetivo comparadas contra nox_proxy_trafico.",
    )
    parser.add_argument(
        "--co2-targets",
        nargs="+",
        default=DEFAULT_CO2_TARGETS,
        help="Variables objetivo comparadas contra co2_proxy_trafico.",
    )
    parser.add_argument(
        "--value-column",
        default=spatial_layer.DEFAULT_VALUE_COLUMN,
        help="Columna numerica del CSV de sensores usada como valor de analisis.",
    )
    parser.add_argument(
        "--sector-id",
        default=spatial_layer.DEFAULT_SECTOR_ID,
        help="Campo identificador del sector. Default: cusec",
    )
    parser.add_argument(
        "--sector-core-radius-km",
        type=float,
        default=spatial_layer.DEFAULT_SECTOR_CORE_RADIUS_KM,
        help="Radio central para definir el area de estudio sectorial.",
    )
    parser.add_argument(
        "--sector-study-buffer-m",
        type=float,
        default=spatial_layer.DEFAULT_SECTOR_STUDY_BUFFER_M,
        help="Buffer del casco convexo de sensores de aire.",
    )
    parser.add_argument(
        "--sector-max-nearest-sensor-km",
        type=float,
        default=spatial_layer.DEFAULT_SECTOR_MAX_NEAREST_SENSOR_KM,
        help="Distancia maxima al sensor de aire mas cercano.",
    )
    parser.add_argument(
        "--sector-influence-radius-km",
        type=float,
        default=spatial_layer.DEFAULT_SECTOR_INFLUENCE_RADIUS_KM,
        help="Radio local usado para la interpolacion sectorial.",
    )
    parser.add_argument(
        "--sector-min-local-stations",
        type=int,
        default=spatial_layer.DEFAULT_SECTOR_MIN_LOCAL_STATIONS,
        help="Numero minimo de estaciones locales por sector y variable.",
    )
    parser.add_argument(
        "--sector-idw-power",
        type=float,
        default=spatial_layer.DEFAULT_SECTOR_IDW_POWER,
        help="Exponente IDW para interpolar a centroides sectoriales.",
    )
    parser.add_argument(
        "--timezone",
        default=spatial_layer.DEFAULT_TIMEZONE,
        help="Huso local usado para construir dias de estudio.",
    )
    parser.add_argument("--start-date", default=None, help="Fecha local inicial opcional YYYY-MM-DD.")
    parser.add_argument("--end-date", default=None, help="Fecha local final opcional YYYY-MM-DD.")
    parser.add_argument(
        "--permutations",
        type=int,
        default=spatial_layer.DEFAULT_PERMUTATIONS,
        help="Numero de permutaciones para Moran/LISA.",
    )
    parser.add_argument(
        "--p-threshold",
        type=float,
        default=spatial_layer.DEFAULT_P_THRESHOLD,
        help="Umbral p para etiquetar clusters locales.",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=DEFAULT_OUTPUT_DIR,
        help="Carpeta de salida para CSV, GeoJSON y resumen JSON.",
    )
    return parser.parse_args()


def load_inventory_daily_factors(
    path: Path,
    timezone: str,
    start_date: pd.Timestamp | None,
    end_date: pd.Timestamp | None,
) -> pd.DataFrame:
    usecols = ["fecha", "emisiones_totales_nox_g", "emisiones_totales_co2_g"] + TRIP_COLUMNS
    frame = pd.read_csv(path, usecols=usecols)
    frame["local_day"] = pd.to_datetime(frame["fecha"], errors="coerce")
    frame = frame.dropna(subset=["local_day"]).copy()
    frame["local_day"] = frame["local_day"].dt.tz_localize(timezone).dt.normalize()

    for column in TRIP_COLUMNS + ["emisiones_totales_nox_g", "emisiones_totales_co2_g"]:
        frame[column] = pd.to_numeric(frame[column], errors="coerce")

    frame["trips_total"] = frame[TRIP_COLUMNS].fillna(0.0).sum(axis=1)
    frame = frame.loc[frame["trips_total"] > 0].copy()

    if start_date is not None:
        frame = frame.loc[frame["local_day"] >= start_date.normalize()]
    if end_date is not None:
        frame = frame.loc[frame["local_day"] <= end_date.normalize()]

    if frame.empty:
        raise ValueError("Inventory CSV does not contain usable rows inside the requested date range.")

    daily = (
        frame.groupby("local_day", as_index=False)
        .agg(
            trips_total=("trips_total", "sum"),
            emisiones_totales_nox_g=("emisiones_totales_nox_g", "sum"),
            emisiones_totales_co2_g=("emisiones_totales_co2_g", "sum"),
            vehiculos=("trips_total", "size"),
        )
        .sort_values("local_day")
        .reset_index(drop=True)
    )
    daily["factor_nox_g_por_viaje"] = daily["emisiones_totales_nox_g"] / daily["trips_total"]
    daily["factor_co2_g_por_viaje"] = daily["emisiones_totales_co2_g"] / daily["trips_total"]
    return daily


def overlap_days(sensor_daily: pd.DataFrame, inventory_daily: pd.DataFrame) -> pd.DatetimeIndex:
    sensor_days = pd.DatetimeIndex(sensor_daily["local_day"].drop_duplicates().sort_values())
    inventory_days = pd.DatetimeIndex(inventory_daily["local_day"].drop_duplicates().sort_values())
    return sensor_days.intersection(inventory_days).sort_values()


def bounds_from_days(days: pd.DatetimeIndex) -> tuple[pd.Timestamp, pd.Timestamp]:
    start_day = pd.Timestamp(days.min())
    end_day = pd.Timestamp(days.max()) + pd.Timedelta(days=1) - pd.Timedelta(microseconds=1)
    return start_day, end_day


def build_augmented_sensor_frame(
    path: Path,
    traffic_param: str,
    inventory_daily: pd.DataFrame,
    overlap_day_index: pd.DatetimeIndex,
    timezone: str,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    frame = pd.read_csv(path)
    frame["time"] = pd.to_datetime(frame["time"], utc=True)
    frame["local_time"] = frame["time"].dt.tz_convert(timezone)
    frame["local_day"] = frame["local_time"].dt.normalize()
    frame = frame.loc[frame["local_day"].isin(overlap_day_index)].copy()

    traffic_rows = frame.loc[frame["param"].astype(str) == traffic_param].copy()
    if traffic_rows.empty:
        raise ValueError(f"No traffic rows with param '{traffic_param}' were found in {path}.")

    traffic_rows["analysis_value_default"] = pd.to_numeric(traffic_rows["analysis_value_default"], errors="coerce")
    traffic_rows = traffic_rows.dropna(subset=["analysis_value_default"]).copy()
    traffic_rows = traffic_rows.merge(
        inventory_daily[["local_day", "factor_nox_g_por_viaje", "factor_co2_g_por_viaje"]],
        on="local_day",
        how="inner",
    )
    if traffic_rows.empty:
        raise ValueError("No overlapping traffic rows remain after joining daily inventory factors.")

    proxy_rows: list[pd.DataFrame] = []
    for proxy_param, factor_column in PROXY_PARAM_FACTORS.items():
        proxy = traffic_rows.copy()
        proxy["source_param"] = traffic_param
        proxy["proxy_factor_column"] = factor_column
        proxy["value"] = proxy["analysis_value_default"] * proxy[factor_column]
        proxy["analysis_value_default"] = proxy["value"]
        if "analysis_value_strict" in proxy.columns:
            proxy["analysis_value_strict"] = proxy["value"]
        if "dataset" in proxy.columns:
            proxy["dataset"] = "traffic_proxy"
        if "domain" in proxy.columns:
            proxy["domain"] = "traffic_proxy"
        if "table" in proxy.columns:
            proxy["table"] = "derived.inventory_traffic_proxy"
        if "qc_status" in proxy.columns:
            proxy["qc_status"] = "derived"
        for flag_column in ["flag_hard_invalid", "flag_soft_suspect", "flag_any_issue"]:
            if flag_column in proxy.columns:
                proxy[flag_column] = False
        if "flag_reason" in proxy.columns:
            proxy["flag_reason"] = ""
        proxy["param"] = proxy_param
        proxy_rows.append(proxy)

    proxy_frame = pd.concat(proxy_rows, ignore_index=True)
    augmented = pd.concat([frame.drop(columns=["local_time", "local_day"]), proxy_frame.drop(columns=["local_time", "local_day"])], ignore_index=True)
    return augmented, proxy_frame


def build_pairs(nox_targets: list[str], co2_targets: list[str]) -> list[tuple[str, str]]:
    pairs = [("nox_proxy_trafico", target) for target in spatial_layer.unique_preserve_order(nox_targets)]
    pairs.extend(("co2_proxy_trafico", target) for target in spatial_layer.unique_preserve_order(co2_targets))
    return pairs


def build_summary(
    args: argparse.Namespace,
    overlap_day_index: pd.DatetimeIndex,
    inventory_daily: pd.DataFrame,
    pairs: list[tuple[str, str]],
    sector_selection: dict[str, object],
    traffic_selection: dict[str, object],
    valid_sector_count_by_variable: dict[str, int],
) -> dict[str, object]:
    output_dir = args.output_dir
    return {
        "article": {
            "journal": "Experimental",
            "year": 2026,
            "volume": None,
            "article_number": None,
            "title": "LISA bivariante con proxies de emision derivados del inventario y el trafico observado",
        },
        "methodology": [
            "Daily factors from the connected-vehicle inventory",
            "NOx and CO2 factors defined as daily total emissions divided by daily total trips",
            "Hourly traffic counts multiplied by the daily inventory factors to build proxy layers",
            "Daily mean by station and variable",
            "Inverse-distance interpolation to sector centroids",
            "Mean value by sector across the full overlapping study period",
            "Queen contiguity weights between sectors",
            "Global Moran's I",
            "Getis-Ord Gi*",
            "Local Moran's I",
            "Bivariate Global Moran's I",
            "Bivariate Local Moran's I",
        ],
        "weight_note": (
            "The inventory is not spatially observed by section. Spatial structure comes from the observed traffic "
            f"parameter '{args.traffic_param}', while the inventory contributes daily emission intensity factors."
        ),
        "inputs": {
            "sensor_csv": str(args.sensor_csv),
            "inventory_csv": str(args.inventory_csv),
            "sectors": str(args.sectors),
            "value_column": args.value_column,
            "sector_id": args.sector_id,
            "traffic_param": args.traffic_param,
            "sensor_variables": spatial_layer.unique_preserve_order(args.sensor_variables),
            "proxy_variables": list(PROXY_PARAM_FACTORS.keys()),
            "nox_targets": spatial_layer.unique_preserve_order(args.nox_targets),
            "co2_targets": spatial_layer.unique_preserve_order(args.co2_targets),
            "bivariate_pairs": [{"variable_x": x, "variable_y": y} for x, y in pairs],
        },
        "study_period_local": {
            "start_day": str(pd.Timestamp(overlap_day_index.min()).date()),
            "end_day": str(pd.Timestamp(overlap_day_index.max()).date()),
        },
        "inventory_daily_factor_summary": {
            "days": int(len(inventory_daily)),
            "mean_nox_factor_g_per_trip": float(inventory_daily["factor_nox_g_por_viaje"].mean()),
            "mean_co2_factor_g_per_trip": float(inventory_daily["factor_co2_g_por_viaje"].mean()),
            "min_nox_factor_g_per_trip": float(inventory_daily["factor_nox_g_por_viaje"].min()),
            "max_nox_factor_g_per_trip": float(inventory_daily["factor_nox_g_por_viaje"].max()),
            "min_co2_factor_g_per_trip": float(inventory_daily["factor_co2_g_por_viaje"].min()),
            "max_co2_factor_g_per_trip": float(inventory_daily["factor_co2_g_por_viaje"].max()),
        },
        "sector_selection": sector_selection,
        "sector_value_filter": {
            "influence_radius_km": float(args.sector_influence_radius_km),
            "min_local_stations": int(args.sector_min_local_stations),
            "valid_sector_count_by_variable": valid_sector_count_by_variable,
        },
        "traffic_selection": traffic_selection,
        "sector_count": int(sector_selection["sector_count"]),
        "outputs": {
            "inventory_daily_factors_csv": str(output_dir / "inventory_daily_factors.csv"),
            "proxy_hourly_rows_csv": str(output_dir / "proxy_hourly_rows.csv"),
            "augmented_sensor_csv": str(output_dir / "combined_flags_with_proxies.csv"),
            "sector_results_geojson": str(output_dir / "sector_results.geojson"),
            "univariate_global_csv": str(output_dir / "univariate_global_results.csv"),
            "bivariate_global_csv": str(output_dir / "bivariate_global_results.csv"),
            "summary_json": str(output_dir / "run_summary.json"),
        },
    }


def write_json(path: Path, payload: dict[str, object]) -> None:
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")


def main() -> None:
    args = parse_args()
    spatial_layer.ensure_output_dir(args.output_dir)

    if args.sector_influence_radius_km <= 0:
        raise ValueError("--sector-influence-radius-km must be > 0")
    if args.sector_min_local_stations < 1:
        raise ValueError("--sector-min-local-stations must be >= 1")
    if args.sector_idw_power <= 0:
        raise ValueError("--sector-idw-power must be > 0")

    requested_start = spatial_layer.parse_local_date(args.start_date, args.timezone, is_end=False)
    requested_end = spatial_layer.parse_local_date(args.end_date, args.timezone, is_end=True)
    sensor_variables = spatial_layer.unique_preserve_order(args.sensor_variables)
    value_column = spatial_layer.resolve_value_column(args.sensor_csv, args.value_column)

    inventory_daily = load_inventory_daily_factors(
        path=args.inventory_csv,
        timezone=args.timezone,
        start_date=requested_start,
        end_date=requested_end,
    )
    sensor_daily_initial, _ = spatial_layer.load_daily_values(
        path=args.sensor_csv,
        variables=sensor_variables,
        value_column=value_column,
        timezone=args.timezone,
        start_date=requested_start,
        end_date=requested_end,
        selected_sectors=None,
    )
    overlap_day_index = overlap_days(sensor_daily_initial, inventory_daily)
    if overlap_day_index.empty:
        raise ValueError("No overlapping local days were found between the inventory and sensor inputs.")

    inventory_daily = inventory_daily.loc[inventory_daily["local_day"].isin(overlap_day_index)].copy()
    augmented_sensor_frame, proxy_hourly_rows = build_augmented_sensor_frame(
        path=args.sensor_csv,
        traffic_param=args.traffic_param,
        inventory_daily=inventory_daily,
        overlap_day_index=overlap_day_index,
        timezone=args.timezone,
    )

    augmented_sensor_csv = args.output_dir / "combined_flags_with_proxies.csv"
    inventory_factors_csv = args.output_dir / "inventory_daily_factors.csv"
    proxy_hourly_csv = args.output_dir / "proxy_hourly_rows.csv"
    augmented_sensor_frame.to_csv(augmented_sensor_csv, index=False)
    inventory_daily.to_csv(inventory_factors_csv, index=False)
    proxy_hourly_rows.to_csv(proxy_hourly_csv, index=False)

    overlap_start, overlap_end = bounds_from_days(overlap_day_index)
    sectors = spatial_layer.load_sectors(args.sectors, args.sector_id)
    air_sensors = spatial_layer.load_air_quality_sensors(
        path=augmented_sensor_csv,
        timezone=args.timezone,
        start_date=overlap_start,
        end_date=overlap_end,
    )
    sectors, sector_selection = spatial_layer.select_study_sectors(
        sectors=sectors,
        air_sensors=air_sensors,
        core_radius_km=args.sector_core_radius_km,
        study_buffer_m=args.sector_study_buffer_m,
        max_nearest_sensor_km=args.sector_max_nearest_sensor_km,
    )
    centroid_xy = spatial_layer.build_centroid_xy(sectors)

    loaded_variables = spatial_layer.unique_preserve_order(sensor_variables + list(PROXY_PARAM_FACTORS.keys()))
    original_traffic_params = set(spatial_layer.TRAFFIC_PARAMS)
    spatial_layer.TRAFFIC_PARAMS = set(spatial_layer.TRAFFIC_PARAMS) | set(PROXY_PARAM_FACTORS.keys())
    try:
        daily_values, traffic_selection = spatial_layer.load_daily_values(
            path=augmented_sensor_csv,
            variables=loaded_variables,
            value_column=value_column,
            timezone=args.timezone,
            start_date=overlap_start,
            end_date=overlap_end,
            selected_sectors=sectors,
        )
    finally:
        spatial_layer.TRAFFIC_PARAMS = original_traffic_params

    sector_values, days_used, valid_sector_count_by_variable = spatial_layer.interpolate_sector_means(
        sectors=sectors,
        centroid_xy=centroid_xy,
        daily_values=daily_values,
        variables=loaded_variables,
        influence_radius_km=args.sector_influence_radius_km,
        min_local_stations=args.sector_min_local_stations,
        idw_power=args.sector_idw_power,
    )

    pairs = build_pairs(args.nox_targets, args.co2_targets)
    sector_values, univariate_global = spatial_layer.compute_univariate_results(
        sectors=sector_values,
        variables=loaded_variables,
        sector_id=args.sector_id,
        permutations=args.permutations,
        p_threshold=args.p_threshold,
    )
    sector_values, bivariate_global = spatial_layer.compute_bivariate_results(
        sectors=sector_values,
        variable_pairs=pairs,
        sector_id=args.sector_id,
        permutations=args.permutations,
        p_threshold=args.p_threshold,
    )

    summary = build_summary(
        args=args,
        overlap_day_index=overlap_day_index,
        inventory_daily=inventory_daily,
        pairs=pairs,
        sector_selection=sector_selection,
        traffic_selection=traffic_selection,
        valid_sector_count_by_variable=valid_sector_count_by_variable,
    )

    sector_results_path = args.output_dir / "sector_results.geojson"
    univariate_path = args.output_dir / "univariate_global_results.csv"
    bivariate_path = args.output_dir / "bivariate_global_results.csv"
    summary_path = args.output_dir / "run_summary.json"

    sector_values.to_file(sector_results_path, driver="GeoJSON")
    univariate_global.to_csv(univariate_path, index=False)
    bivariate_global.to_csv(bivariate_path, index=False)
    write_json(summary_path, summary)

    print(f"Augmented sensor CSV: {augmented_sensor_csv}")
    print(f"Inventory daily factors: {inventory_factors_csv}")
    print(f"Proxy hourly rows: {proxy_hourly_csv}")
    print(f"Sector results: {sector_results_path}")
    print(f"Univariate global results: {univariate_path}")
    print(f"Bivariate global results: {bivariate_path}")
    print(f"Summary: {summary_path}")


if __name__ == "__main__":
    main()
